using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace art_api.Models;
public class Artist
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    [BsonElement("name")]
    public string Name { get; set; }

    [BsonElement("dob")]
    public int DOB { get; set; }

    [BsonElement("born")]
    public string Born { get; set; }

    [BsonElement("languagegroup")]
    public string LanguageGroup { get; set; }
    
    [BsonElement("community")]
    public string? Community { get; set; }
    
    [BsonElement("description")]
    public string? Description { get; set; }
}
