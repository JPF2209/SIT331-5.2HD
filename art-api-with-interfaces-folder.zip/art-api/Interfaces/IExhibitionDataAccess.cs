using System.Collections.Generic;
using art_api.Models;

namespace art_api.Services
{
    public interface IExhibitionDataAccess
    {
        Task<List<Exhibition>> GetAllExhibitionsAsync(); 
        Task<Exhibition?> GetExhibitionByIdAsync(string id);
        Task<List<Exhibition>> GetExhibitionByCurrentAsync(bool current);
        Task<Exhibition?> InsertExhibitionAsync(Exhibition exhibition);
        Task<Exhibition?> UpdateExhibitionAsync(Exhibition exhibition);
        Task<bool> DeleteExhibitionAsync(string id); 
    }
}

