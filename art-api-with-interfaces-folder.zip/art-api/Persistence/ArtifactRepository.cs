using art_api.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using art_api.Settings;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;
namespace art_api.Persistence
{
    public class ArtifactRepository : IArtifactRepository
    {
        private readonly IMongoCollection<Artifact> _collection;

        public ArtifactRepository(IOptions<MongoDbSettings> settings, IMongoClient client)
        {
            var db = client.GetDatabase(settings.Value.DatabaseName); 
            _collection = db.GetCollection<Artifact>("artifacts");
        }

        public async Task<Artifact?> GetByTitleAsync(string Title)
        {
            return await _collection.Find(a => a.Title == Title).FirstOrDefaultAsync();
        }

        public async Task<Artifact> InsertAsync(Artifact artifact, bool isChecked)
        {
            // For Xunit test, check if not in DB
            if (isChecked == false)
            {
                var filter = Builders<Artifact>.Filter.Eq(a => a.Title, artifact.Title);
                var existing = await _collection.Find(filter).FirstOrDefaultAsync();

                if (existing != null)
                    return null;
            }
            await _collection.InsertOneAsync(artifact);
            return artifact;
        }

        public async Task<List<Artifact>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task<Artifact?> GetByIdAsync(string id)
        {
            return await _collection.Find(a => a.Id == id).FirstOrDefaultAsync();
        }

        public async Task<List<Artifact>> GetFilteredArtifactsAsync(bool? framed, bool? @new, bool? staffPick)
        {
            var filters = new List<FilterDefinition<Artifact>>();

            // For filters, check if they are true or false
            if (framed.HasValue)
                filters.Add(Builders<Artifact>.Filter.Eq(a => a.Framed, framed.Value));

            if (@new.HasValue)
                filters.Add(Builders<Artifact>.Filter.Eq(a => a.New, @new.Value));

            if (staffPick.HasValue)
                filters.Add(Builders<Artifact>.Filter.Eq(a => a.StaffPicks, staffPick.Value));

            var filter = filters.Any() ? Builders<Artifact>.Filter.And(filters) : Builders<Artifact>.Filter.Empty;

            return await _collection.Find(filter).ToListAsync();
        }

        public async Task<List<Artifact>> GetArtifactsByTypeAsync(string typeTitle)
        {
            var filter = Builders<Artifact>.Filter.Eq("type.title", typeTitle);
            return await _collection.Find(filter).ToListAsync();

        }

        public async Task<Artifact> UpdateAsync(Artifact artifact, bool isChecked)
        {
            // For Xunit test, check if in DB
            if (isChecked == false)
            {
                var existingArtifact = await _collection.Find(a => a.Title == artifact.Title).FirstOrDefaultAsync();

                if (existingArtifact != null)
                {
                    return null;
                }
            }
            var filter = Builders<Artifact>.Filter.Eq(a => a.Id, artifact.Id);
            var result = await _collection.ReplaceOneAsync(filter, artifact);

            // If it updated, return exhibition
            if (result.IsAcknowledged && result.ModifiedCount > 0)
                return artifact;

            return null; // Update failed
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var result = await _collection.DeleteOneAsync(a => a.Id == id);
            return result.DeletedCount > 0;
        }
    }
}