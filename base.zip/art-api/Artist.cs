using art_api.Persistence;

namespace art_api;
public class Artist
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int DOB { get; set; }
    public string Born { get; set; }
    public string LanguageGroup { get; set; }
    public string Community { get; set; }
    public string? Description { get; set; }
}
