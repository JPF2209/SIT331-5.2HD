using System.Collections.Generic;
using art_api;

namespace art_api.Persistence
{
    public interface IArtifactDataAccess
    {
        List<Artifact> GetArtifacts();
        Artifact GetArtifactByID(int id);
        List<Artifact> GetFilteredArtifacts(bool? framed, bool? isNew, bool? staffPick);
        public List<Artifact> GetArtifactsByType(string typeTitle);
        Artifact InsertArtifacts(Artifact Artifact);
        Artifact UpdateArtifacts(int id, Artifact Artifact);
        void DeleteArtifacts(int id);
    }
}
