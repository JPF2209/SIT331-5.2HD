using Npgsql;
using System.Collections.Generic;
using System.Linq;

namespace art_api.Persistence
{
    public class TypeRepository : IRepository, ITypeDataAccess
    {
        private IRepository _repo => this;

        public List<ArtifactType> GetTypes()
        {
            return _repo.ExecuteReader<ArtifactType>("SELECT * FROM public.types;");
        }

        public ArtifactType GetTypeByID(int id)
        {
            var parameters = new NpgsqlParameter[] { new("id", id) };
            try
            {
                return _repo.ExecuteReader<ArtifactType>(
                    "SELECT * FROM public.types WHERE id = @id;", 
                    parameters
                ).SingleOrDefault();
            }
            catch
            {
                return null;
            }
        }

        public ArtifactType InsertTypes(ArtifactType type)
        {
            var checkParams = new NpgsqlParameter[] { new("title", type.Title) };
            try
            {
                var exists = _repo.ExecuteReader<ArtifactType>(
                    "SELECT * FROM public.types WHERE title = @title;", 
                    checkParams
                ).SingleOrDefault();

                if (exists != null)
                    return null;
            }
            catch
            {
                // No existing record found, safe to insert
            }

            var sqlParams = new NpgsqlParameter[]
            {
                new("title", type.Title),
                new("description", type.Description ?? (object)DBNull.Value)
            };

            return _repo.ExecuteReader<ArtifactType>(
                "INSERT INTO public.types (title, description) " +
                "VALUES (@title, @description) RETURNING *;", 
                sqlParams
            ).SingleOrDefault();
        }

        public ArtifactType UpdateTypes(ArtifactType type)
        {
            var sqlParams = new NpgsqlParameter[]
            {
                new("id", type.Id),
                new("title", type.Title),
                new("description", type.Description ?? (object)DBNull.Value)
            };

            try
            {
                return _repo.ExecuteReader<ArtifactType>(
                    "UPDATE public.types SET title = @title, description = @description " +
                    "WHERE id = @id RETURNING *;", 
                    sqlParams
                ).SingleOrDefault();
            }
            catch
            {
                return null;
            }
        }

        public void DeleteTypes(int id)
        {
            var sqlParams = new NpgsqlParameter[] { new("id", id) };
            _repo.ExecuteReader<ArtifactType>(
                "DELETE FROM public.types WHERE id = @id;",
                sqlParams
            );
        }
    }
}
