using Npgsql;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
namespace art_api.Persistence
{
    public class ArtistADO : IArtistDataAccess
    {
        private const string CONNECTION_STRING = "Host=localhost;Username=postgres;Password=jpf2209;Database=art";

        public List<Artist> GetArtists()
        {
            var artists = new List<Artist>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM artist;", conn);
            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                artists.Add(MapArtist(dr));
            }
            return artists;
        }

        public Artist GetArtistByID(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM artist WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                return MapArtist(dr);
            }
            return null;
        }

        public Artist InsertArtists(Artist newArtist)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            // Optional: prevent duplicate names
            using (var checkCmd = new NpgsqlCommand("SELECT COUNT(*) FROM artist WHERE name = @name", conn))
            {
                checkCmd.Parameters.AddWithValue("@name", newArtist.Name);
                var count = (long)checkCmd.ExecuteScalar();
                if (count > 0) return null; // Conflict
            }

            using var cmd = new NpgsqlCommand(
                "INSERT INTO artist (name, dob, born, languagegroup, community, description) " +
                "VALUES (@name, @dob, @born, @languagegroup, @community, @description) RETURNING *", conn);
            cmd.Parameters.AddWithValue("@name", newArtist.Name);
            cmd.Parameters.AddWithValue("@dob", newArtist.DOB);
            cmd.Parameters.AddWithValue("@born", newArtist.Born ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@languagegroup", newArtist.LanguageGroup ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@community", newArtist.Community ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@description", newArtist.Description ?? (object)DBNull.Value);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapArtist(dr) : null;
        }

        public Artist UpdateArtists(Artist updatedArtist)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            using var cmd = new NpgsqlCommand(
                "UPDATE artist SET name = @name, dob = @dob, born = @born, " +
                "languagegroup = @languagegroup, community = @community, description = @description " +
                "WHERE id = @id RETURNING *", conn);
            cmd.Parameters.AddWithValue("@id", updatedArtist.Id);
            cmd.Parameters.AddWithValue("@name", updatedArtist.Name);
            cmd.Parameters.AddWithValue("@dob", updatedArtist.DOB);
            cmd.Parameters.AddWithValue("@born", updatedArtist.Born ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@languagegroup", updatedArtist.LanguageGroup ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@community", updatedArtist.Community ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@description", updatedArtist.Description ?? (object)DBNull.Value);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapArtist(dr) : null;
        }

        public void DeleteArtists(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("DELETE FROM artist WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        public List<Artist> GetArtistsByCommunity(string community)
        {
            var artists = new List<Artist>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM artist WHERE community = @community", conn);
            cmd.Parameters.AddWithValue("@community", community);
            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                artists.Add(MapArtist(dr));
            }
            return artists;
        }

        private Artist MapArtist(NpgsqlDataReader dr)
        {
            return new Artist
            {
                Id = dr.GetInt32(0),
                Name = dr.GetString(1),
                DOB = dr.GetInt32(2),
                Born = dr.IsDBNull(3) ? null : dr.GetString(3),
                LanguageGroup = dr.IsDBNull(4) ? null : dr.GetString(4),
                Community = dr.IsDBNull(5) ? null : dr.GetString(5),
                Description = dr.IsDBNull(6) ? null : dr.GetString(6)
            };
        }
    }
}
