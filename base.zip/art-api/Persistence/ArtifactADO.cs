using Npgsql;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
namespace art_api.Persistence
{
    public class ArtifactADO : IArtifactDataAccess
    {
        private const string CONNECTION_STRING = "Host=localhost;Username=postgres;Password=jpf2209;Database=art";

        public List<Artifact> GetArtifacts()
        {
            var artifacts = new List<Artifact>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM artifact;", conn);
            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                artifacts.Add(MapArtifact(dr));
            }
            return artifacts;
        }

        public Artifact GetArtifactByID(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM artifact WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                return MapArtifact(dr);
            }
            return null;
        }

        public List<Artifact> GetFilteredArtifacts(bool? framed, bool? isNew, bool? staffPick)
        //public List<Artifact> GetFilteredArtifacts(bool? framed, bool? isNew, bool? staffPick)
        {
            var artifacts = new List<Artifact>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            var conditions = new List<string>();
            var parameters = new List<NpgsqlParameter>();

            if (framed.HasValue)
            {
                conditions.Add("framed = @framed");
                parameters.Add(new NpgsqlParameter("@framed", framed.Value));
            }

            if (isNew.HasValue)
            {
                conditions.Add("\"new\" = @new");
                parameters.Add(new NpgsqlParameter("@new", isNew.Value));
            }

            if (staffPick.HasValue)
            {
                conditions.Add("staffpicks = @staffPick");
                parameters.Add(new NpgsqlParameter("@staffPick", staffPick.Value));
            }

            var whereClause = conditions.Count > 0 ? "WHERE " + string.Join(" AND ", conditions) : "";
            var query = $"SELECT * FROM artifact {whereClause}";

            using var cmd = new NpgsqlCommand(query, conn);
            cmd.Parameters.AddRange(parameters.ToArray());

            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                artifacts.Add(MapArtifact(dr));
            }

            return artifacts;
        }


        public List<Artifact> GetArtifactsByType(string typeTitle)
        {
            var artifacts = new List<Artifact>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            string query = @"
                SELECT a.*
                FROM artifact a
                JOIN type t ON a.typeid = t.id
                WHERE t.title = @typeTitle";

            using var cmd = new NpgsqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@typeTitle", typeTitle);

            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                artifacts.Add(MapArtifact(dr));
            }

            return artifacts;
        }



        public Artifact InsertArtifacts(Artifact newArtifact)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            using var cmd = new NpgsqlCommand(@"
                INSERT INTO artifact 
                (title, artistid, productno, framed, size, medium, price, saleprice, onsale, 
                typeid, colour, shape, new, staffpicks, exhibitionid)
                VALUES 
                (@title, @artistid, @productno, @framed, @size, @medium, @price, @saleprice, @onsale, 
                @typeid, @colour, @shape, @new, @staffpicks, @exhibitionid)
                RETURNING *", conn);

            cmd.Parameters.AddWithValue("@title", newArtifact.Title);
            cmd.Parameters.AddWithValue("@artistid", newArtifact.ArtistId);
            cmd.Parameters.AddWithValue("@productno", newArtifact.ProductNo);
            cmd.Parameters.AddWithValue("@framed", newArtifact.Framed);
            cmd.Parameters.AddWithValue("@size", newArtifact.Size);
            cmd.Parameters.AddWithValue("@medium", newArtifact.Medium);
            cmd.Parameters.AddWithValue("@price", newArtifact.Price);
            cmd.Parameters.AddWithValue("@saleprice", newArtifact.SalePrice ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@onsale", newArtifact.OnSale);
            cmd.Parameters.AddWithValue("@typeid", newArtifact.TypeId);
            cmd.Parameters.AddWithValue("@colour", newArtifact.Colour);
            cmd.Parameters.AddWithValue("@shape", newArtifact.Shape);
            cmd.Parameters.AddWithValue("@new", newArtifact.New);
            cmd.Parameters.AddWithValue("@staffpicks", newArtifact.StaffPicks);
            cmd.Parameters.AddWithValue("@exhibitionid", newArtifact.ExhibitionId ?? (object)DBNull.Value);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapArtifact(dr) : null;
        }


        public Artifact UpdateArtifacts(int id, Artifact updatedArtifact)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            using var cmd = new NpgsqlCommand(@"
                UPDATE artifact SET 
                    title = @title,
                    artistid = @artistid,
                    productno = @productno,
                    framed = @framed,
                    size = @size,
                    medium = @medium,
                    price = @price,
                    saleprice = @saleprice,
                    onsale = @onsale,
                    typeid = @typeid,
                    colour = @colour,
                    shape = @shape,
                    new = @new,
                    staffpicks = @staffpicks,
                    exhibitionid = @exhibitionid
                WHERE id = @id
                RETURNING *", conn);

            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@title", updatedArtifact.Title);
            cmd.Parameters.AddWithValue("@artistid", updatedArtifact.ArtistId);
            cmd.Parameters.AddWithValue("@productno", updatedArtifact.ProductNo);
            cmd.Parameters.AddWithValue("@framed", updatedArtifact.Framed);
            cmd.Parameters.AddWithValue("@size", updatedArtifact.Size);
            cmd.Parameters.AddWithValue("@medium", updatedArtifact.Medium);
            cmd.Parameters.AddWithValue("@price", updatedArtifact.Price);
            cmd.Parameters.AddWithValue("@saleprice", updatedArtifact.SalePrice ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@onsale", updatedArtifact.OnSale);
            cmd.Parameters.AddWithValue("@typeid", updatedArtifact.TypeId);
            cmd.Parameters.AddWithValue("@colour", updatedArtifact.Colour);
            cmd.Parameters.AddWithValue("@shape", updatedArtifact.Shape);
            cmd.Parameters.AddWithValue("@new", updatedArtifact.New);
            cmd.Parameters.AddWithValue("@staffpicks", updatedArtifact.StaffPicks);
            cmd.Parameters.AddWithValue("@exhibitionid", updatedArtifact.ExhibitionId ?? (object)DBNull.Value);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapArtifact(dr) : null;
        }


        public void DeleteArtifacts(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("DELETE FROM artifact WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        private Artifact MapArtifact(NpgsqlDataReader dr)
        {
            return new Artifact
            {
                Id = dr.GetInt32(dr.GetOrdinal("id")),
                Title = dr.GetString(dr.GetOrdinal("title")),
                ArtistId = dr.GetInt32(dr.GetOrdinal("artistid")),
                ProductNo = dr.GetString(dr.GetOrdinal("productno")),
                Framed = dr.GetBoolean(dr.GetOrdinal("framed")),
                Size = dr.GetString(dr.GetOrdinal("size")),
                Medium = dr.GetString(dr.GetOrdinal("medium")),
                Price = dr.GetDouble(dr.GetOrdinal("price")),
                SalePrice = dr.IsDBNull(dr.GetOrdinal("saleprice")) ? null : dr.GetDouble(dr.GetOrdinal("saleprice")),
                OnSale = dr.GetBoolean(dr.GetOrdinal("onsale")),
                TypeId = dr.GetInt32(dr.GetOrdinal("typeid")),
                Colour = dr.GetString(dr.GetOrdinal("colour")),
                Shape = dr.GetString(dr.GetOrdinal("shape")),
                New = dr.GetBoolean(dr.GetOrdinal("new")),
                StaffPicks = dr.GetBoolean(dr.GetOrdinal("staffpicks")),
                ExhibitionId = dr.IsDBNull(dr.GetOrdinal("exhibitionid")) ? null : dr.GetInt32(dr.GetOrdinal("exhibitionid"))
            };
        }

    }
}
