using Microsoft.AspNetCore.Mvc;
using art_api.Persistence;


namespace art_api.Controllers;

[ApiController]
[Route("api/artifact")]
public class ArtifactsController : ControllerBase
{
    private readonly IArtifactDataAccess _artifactsRepo;
    public ArtifactsController(IArtifactDataAccess artifactsRepo)
    {
        _artifactsRepo = artifactsRepo;
    }

    [HttpGet("")]
    public IEnumerable<Artifact> GetAllArtifacts()
    {
        return  _artifactsRepo.GetArtifacts();
    }

    [HttpGet("artifacts/by-filter")]
    public ActionResult<IEnumerable<Artifact>> GetFilteredArtifacts(
        [FromQuery] bool? framed,
        [FromQuery] bool? @new,
        [FromQuery] bool? staffPick)
    {
        var artifacts = _artifactsRepo.GetFilteredArtifacts(framed, @new, staffPick);
        return Ok(artifacts);
    }

    [HttpGet("artifacts/by-type")]
    public ActionResult<IEnumerable<Artifact>> GetArtifactsByType([FromQuery] string typeTitle)
    {
        var artifacts = _artifactsRepo.GetArtifactsByType(typeTitle);
        return Ok(artifacts);
    }

    [HttpGet("{id}", Name =  "GetArtifact")]
    public IActionResult GetArtifactById (int id)
    {
        Artifact Artifact =  _artifactsRepo.GetArtifactByID(id);
        if (Artifact == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(Artifact);
        }
    }

    [HttpPost()]
    public IActionResult AddArtifact (Artifact newArtifact)
    {
        if (newArtifact == null)
        {
            return BadRequest();
        }
        Artifact Artifact =  _artifactsRepo.InsertArtifacts(newArtifact);
        if (Artifact == null)
        {
            return Conflict();
        }
        else
        {
            return CreatedAtRoute("GetArtifact", new {id = Artifact.Id}, Artifact); 
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateArtifact(int id, Artifact updatedArtifact)
    {
        Artifact foundArtifact =  _artifactsRepo.GetArtifactByID(id);
        //Makes sure robot isn't empty
        if (foundArtifact == null)
        {
            return NotFound();
        }
        //Checks if a new robot has been able to been made
        Artifact newArtifact =  _artifactsRepo.UpdateArtifacts(id, updatedArtifact);
        if (newArtifact == null)
        {
            return BadRequest();
        }
        else
        {            
            return NoContent();
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteArtifact(int id)
    {
        Artifact foundArtifact =  _artifactsRepo.GetArtifactByID(id);
        //Checks if robot exists or not
        if (foundArtifact == null)
        {
            return NotFound();
        }        
         _artifactsRepo.DeleteArtifacts(id);
        return NoContent();
    }
}
