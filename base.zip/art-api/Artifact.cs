namespace art_api;

public class Artifact
{
    public int Id { get; set; }
    public string Title { get; set; }
    public int ArtistId { get; set; } // FK
    public Artist Artist { get; set; }

    public string ProductNo { get; set; }
    public bool Framed { get; set; }
    public string Size { get; set; }
    public string Medium { get; set; }
    public double Price { get; set; }
    public double? SalePrice { get; set; }
    public bool OnSale { get; set; }

    public int TypeId { get; set; } // FK
    public ArtifactType Type { get; set; }

    public string Colour { get; set; }
    public string Shape { get; set; }
    public bool New { get; set; }
    public bool StaffPicks { get; set; }

    public int? ExhibitionId { get; set; } // Optional FK
    public Exhibition Exhibition { get; set; }
}
