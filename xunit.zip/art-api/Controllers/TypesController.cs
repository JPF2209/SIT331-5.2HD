using Microsoft.AspNetCore.Mvc;
using art_api.Persistence;


namespace art_api.Controllers;

[ApiController]
[Route("api/type")]
public class TypesController : ControllerBase
{
    private readonly ITypeDataAccess _typesRepo;
    
    public TypesController(ITypeDataAccess typesRepo)
    {
        _typesRepo = typesRepo;
    }

    [HttpGet("")]
    public IEnumerable<ArtifactType> GetAllTypes()
    {
        return  _typesRepo.GetTypes();
    }

    [HttpGet("{id}", Name =  "GetType")]
    public IActionResult GetTypeById (int id)
    {
        ArtifactType Type =  _typesRepo.GetTypeByID(id);
        if (Type == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(Type);
        }
    }

    [HttpPost()]
    public IActionResult AddType (ArtifactType newType)
    {
        if (newType == null)
        {
            return BadRequest();
        }
        ArtifactType Type =  _typesRepo.InsertTypes(newType);
        if (Type == null)
        {
            return Conflict();
        }
        else
        {
            return CreatedAtRoute("GetType", new {id = Type.Id}, Type); 
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateType(int id, ArtifactType updatedType)
    {
        ArtifactType foundType =  _typesRepo.GetTypeByID(id);
        //Makes sure robot isn't empty
        if (foundType == null)
        {
            return NotFound();
        }
        //Checks if a new robot has been able to been made
        ArtifactType newType =  _typesRepo.UpdateTypes(updatedType);
        if (newType == null)
        {
            return BadRequest();
        }
        else
        {            
            return NoContent();
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteType(int id)
    {
        ArtifactType foundType =  _typesRepo.GetTypeByID(id);
        //Checks if robot exists or not
        if (foundType == null)
        {
            return NotFound();
        }        
         _typesRepo.DeleteTypes(id);
        return NoContent();
    }
}
