using Microsoft.AspNetCore.Mvc;
using art_api.Persistence;


namespace art_api.Controllers;

[ApiController]
[Route("api/artist")]
public class ArtistsController : ControllerBase
{
    private readonly IArtistDataAccess _artistsRepo;
    public ArtistsController(IArtistDataAccess artistsRepo)
    {
        _artistsRepo = artistsRepo;
    }

    [HttpGet("")]
    public IEnumerable<Artist> GetAllArtists()
    {
        return  _artistsRepo.GetArtists();
    }

    [HttpGet("by-community")]
    public ActionResult<IEnumerable<Artist>> GetArtistsByCommunity([FromQuery] string community)
    {
        var artists = _artistsRepo.GetArtistsByCommunity(community);
        return Ok(artists);
    }


    [HttpGet("{id}", Name =  "GetArtist")]
    public IActionResult GetArtistById (int id)
    {
        Artist Artist =  _artistsRepo.GetArtistByID(id);
        if (Artist == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(Artist);
        }
    }

    [HttpPost()]
    public IActionResult AddArtist (Artist newArtist)
    {
        if (newArtist == null)
        {
            return BadRequest();
        }
        Artist Artist =  _artistsRepo.InsertArtists(newArtist);
        if (Artist == null)
        {
            return Conflict();
        }
        else
        {
            return CreatedAtRoute("GetArtist", new {id = Artist.Id}, Artist); 
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateArtist(int id, Artist updatedArtist)
    {
        Artist foundArtist =  _artistsRepo.GetArtistByID(id);
        //Makes sure robot isn't empty
        if (foundArtist == null)
        {
            return NotFound();
        }
        //Checks if a new robot has been able to been made
        Artist newArtist =  _artistsRepo.UpdateArtists(updatedArtist);
        if (newArtist == null)
        {
            return BadRequest();
        }
        else
        {            
            return NoContent();
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteArtist(int id)
    {
        Artist foundArtist =  _artistsRepo.GetArtistByID(id);
        //Checks if robot exists or not
        if (foundArtist == null)
        {
            return NotFound();
        }        
         _artistsRepo.DeleteArtists(id);
        return NoContent();
    }
}
