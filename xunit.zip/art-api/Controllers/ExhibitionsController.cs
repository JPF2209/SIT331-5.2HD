using Microsoft.AspNetCore.Mvc;
using art_api.Persistence;


namespace art_api.Controllers;

[ApiController]
[Route("api/exhibition")]
public class ExhibitionsController : ControllerBase
{
    private readonly IExhibitionDataAccess _exhibitionsRepo;
    public ExhibitionsController(IExhibitionDataAccess exhibitionsRepo)
    {
        _exhibitionsRepo = exhibitionsRepo;
    }

    [HttpGet("")]
    public IEnumerable<Exhibition> GetAllExhibitions()
    {
        return  _exhibitionsRepo.GetExhibitions();
    }

    [HttpGet("current")]
    public ActionResult<IEnumerable<Exhibition>> GetCurrentExhibitions()
    {
        var exhibitions = _exhibitionsRepo.GetExhibitionsByCurrent(true);
        return Ok(exhibitions);
    }

    [HttpGet("{id}", Name =  "GetExhibition")]
    public IActionResult GetExhibitionById (int id)
    {
        Exhibition Exhibition =  _exhibitionsRepo.GetExhibitionByID(id);
        if (Exhibition == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(Exhibition);
        }
    }

    [HttpPost()]
    public IActionResult AddExhibition (Exhibition newExhibition)
    {
        if (newExhibition == null)
        {
            return BadRequest();
        }
        Exhibition Exhibition =  _exhibitionsRepo.InsertExhibitions(newExhibition);
        if (Exhibition == null)
        {
            return Conflict();
        }
        else
        {
            return CreatedAtRoute("GetExhibition", new {id = Exhibition.Id}, Exhibition); 
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateExhibition(int id, Exhibition updatedExhibition)
    {
        Exhibition foundExhibition =  _exhibitionsRepo.GetExhibitionByID(id);
        //Makes sure robot isn't empty
        if (foundExhibition == null)
        {
            return NotFound();
        }
        //Checks if a new robot has been able to been made
        Exhibition newExhibition =  _exhibitionsRepo.UpdateExhibitions(updatedExhibition);
        if (newExhibition == null)
        {
            return BadRequest();
        }
        else
        {            
            return NoContent();
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteExhibition(int id)
    {
        Exhibition foundExhibition =  _exhibitionsRepo.GetExhibitionByID(id);
        //Checks if robot exists or not
        if (foundExhibition == null)
        {
            return NotFound();
        }        
         _exhibitionsRepo.DeleteExhibitions(id);
        return NoContent();
    }
}
