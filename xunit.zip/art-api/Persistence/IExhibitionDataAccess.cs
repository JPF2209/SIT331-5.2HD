using System.Collections.Generic;
using art_api;

namespace art_api.Persistence
{
    public interface IExhibitionDataAccess
    {
        List<Exhibition> GetExhibitions();
        Exhibition GetExhibitionByID(int id);
        Exhibition InsertExhibitions(Exhibition Exhibition);
        Exhibition UpdateExhibitions(Exhibition Exhibition);
        void DeleteExhibitions(int id);
        List<Exhibition> GetExhibitionsByCurrent(bool current);
    }
}
