using Npgsql;

public interface IRepository
{
    List<T> ExecuteReader<T>(string sqlCommand, NpgsqlParameter[]? dbParams = null) where T : class, new();
}
