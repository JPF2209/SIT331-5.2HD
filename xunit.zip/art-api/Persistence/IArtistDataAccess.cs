using System.Collections.Generic;
using art_api;

namespace art_api.Persistence
{
    public interface IArtistDataAccess
    {
        List<Artist> GetArtists();
        Artist GetArtistByID(int id);
        Artist InsertArtists(Artist artist);
        Artist UpdateArtists(Artist artist);
        void DeleteArtists(int id);
        List<Artist> GetArtistsByCommunity(string community);
    }
}
