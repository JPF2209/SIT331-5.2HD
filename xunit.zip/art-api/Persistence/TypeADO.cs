using Microsoft.AspNetCore.Mvc;
using Npgsql;

namespace art_api.Persistence
{
    public class TypeADO : ITypeDataAccess
    {
        private const string CONNECTION_STRING = "Host=localhost;Username=postgres;Password=jpf2209;Database=art";

        public List<ArtifactType> GetTypes()
        {
            var types = new List<ArtifactType>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM type;", conn);
            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                types.Add(MapType(dr));
            }
            return types;
        }

        public ArtifactType GetTypeByID(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM type WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapType(dr) : null;
        }

        public ArtifactType InsertTypes(ArtifactType newType)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            using (var checkCmd = new NpgsqlCommand("SELECT COUNT(*) FROM type WHERE title = @title", conn))
            {
                checkCmd.Parameters.AddWithValue("@title", newType.Title);
                var count = (long)checkCmd.ExecuteScalar();
                if (count > 0) return null;
            }

            using var cmd = new NpgsqlCommand(
                "INSERT INTO type (title, description) VALUES (@title, @description) RETURNING *", conn);
            cmd.Parameters.AddWithValue("@title", newType.Title);
            cmd.Parameters.AddWithValue("@description", newType.Description ?? (object)DBNull.Value);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapType(dr) : null;
        }

        public ArtifactType UpdateTypes(ArtifactType updatedType)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            using var cmd = new NpgsqlCommand(
                "UPDATE type SET title = @title, description = @description WHERE id = @id RETURNING *", conn);
            cmd.Parameters.AddWithValue("@id", updatedType.Id);
            cmd.Parameters.AddWithValue("@title", updatedType.Title);
            cmd.Parameters.AddWithValue("@description", updatedType.Description ?? (object)DBNull.Value);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapType(dr) : null;
        }

        public void DeleteTypes(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("DELETE FROM type WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        private ArtifactType MapType(NpgsqlDataReader dr)
        {
            return new ArtifactType
            {
                Id = dr.GetInt32(0),
                Title = dr.GetString(1),
                Description = dr.IsDBNull(2) ? null : dr.GetString(2)
            };
        }
    }
}

