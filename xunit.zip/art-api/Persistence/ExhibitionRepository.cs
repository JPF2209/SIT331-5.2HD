using Npgsql;

namespace art_api.Persistence
{
    public class ExhibitionRepository : IExhibitionDataAccess
    {
        private readonly IRepository _repo;

        public ExhibitionRepository(IRepository repo)
        {
            _repo = repo;
        }

        public List<Exhibition> GetExhibitions()
        {
            return _repo.ExecuteReader<Exhibition>("SELECT * FROM public.exhibition;");
        }

        public Exhibition GetExhibitionByID(int id)
        {
            var parameters = new NpgsqlParameter[] { new("id", id) };
            try
            {
                return _repo.ExecuteReader<Exhibition>("SELECT * FROM public.exhibition WHERE id = @id;", 
                    parameters).Single();
            }
            catch
            {
                return null;
            }
        }

        public Exhibition InsertExhibitions(Exhibition exhibition)
        {
            var checkParams = new NpgsqlParameter[] { new("title", exhibition.Title) };
            try
            {
                var existing = _repo.ExecuteReader<Exhibition>(
                    "SELECT * FROM public.exhibition WHERE title = @title;",
                    checkParams);

                if (existing?.Any() == true)
                    return null;
            }
            catch
            {
                // Continue to insert if SELECT failed
            }

            var sqlParams = new NpgsqlParameter[]
            {
                new("title", exhibition.Title),
                new("startdate", exhibition.StartDate),
                new("enddate", exhibition.EndDate),
                new("description", exhibition.Description ?? (object)DBNull.Value),
                new("current", exhibition.Current)
            };

            return _repo.ExecuteReader<Exhibition>(
                "INSERT INTO public.exhibition (title, startdate, enddate, description, current) " +
                "VALUES (@title, @startdate, @enddate, @description, @current) RETURNING *;",
                sqlParams)?.Single();
        }


        public Exhibition UpdateExhibitions(Exhibition exhibition)
        {
            var sqlParams = new NpgsqlParameter[]
            {
                new("id", exhibition.Id),
                new("title", exhibition.Title),
                new("startdate", exhibition.StartDate),
                new("enddate", exhibition.EndDate),
                new("description", exhibition.Description ?? (object)DBNull.Value),
                new("current", exhibition.Current)
            };

            try
            {
                return _repo.ExecuteReader<Exhibition>(
                    "UPDATE public.exhibition SET title = @title, startdate = @startdate, enddate = @enddate, " +
                    "\"description\" = @description, \"current\" = @current WHERE id = @id RETURNING *;", 
                    sqlParams).Single();
            }
            catch
            {
                return null;
            }
        }

        public void DeleteExhibitions(int id)
        {
            var sqlParams = new NpgsqlParameter[] { new("id", id) };
            _repo.ExecuteReader<Exhibition>("DELETE FROM public.exhibition WHERE id = @id;", 
                    sqlParams);
        }

        public List<Exhibition> GetExhibitionsByCurrent(bool current)
        {
            var sqlParams = new NpgsqlParameter[] { new("current", current) };
            return _repo.ExecuteReader<Exhibition>("SELECT * FROM public.exhibition WHERE \"current\" = @current;", 
                    sqlParams);
        }
    }
}
