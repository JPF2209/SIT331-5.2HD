using Npgsql;
namespace art_api.Persistence
{
    public class ArtistRepository : IArtistDataAccess
    {
        private readonly IRepository _repo;

        public ArtistRepository(IRepository repo)
        {
            _repo = repo;
        }
        
        public List<Artist> GetArtists()
        {
            return _repo.ExecuteReader<Artist>("SELECT * FROM public.artist;");
        }

        public Artist? GetArtistByID(int id)
        {
            var parameters = new NpgsqlParameter[] { new("id", id) };
            try
            {
                return _repo.ExecuteReader<Artist>("SELECT * FROM public.artist WHERE id = @id;", 
                    parameters).Single();
            }
            catch
            {
                return null;
            }
        }

        public Artist InsertArtists(Artist artist)
        {
            var checkParams = new NpgsqlParameter[] { new("name", artist.Name) };
            try
            {
                var exists = _repo.ExecuteReader<Artist>("SELECT * FROM public.artist WHERE name = @name;", 
                    checkParams).Single();
                return null;
            }
            catch
            {
                var sqlParams = new NpgsqlParameter[]
                {
                    new("name", artist.Name),
                    new("dob", artist.DOB),
                    new("born", artist.Born ?? (object)DBNull.Value),
                    new("languagegroup", artist.LanguageGroup ?? (object)DBNull.Value),
                    new("community", artist.Community ?? (object)DBNull.Value),
                    new("description", artist.Description ?? (object)DBNull.Value)
                };
                return _repo.ExecuteReader<Artist>(
                    "INSERT INTO public.artist (name, dob, born, languagegroup, community, description) " +
                    "VALUES (@name, @dob, @born, @languagegroup, @community, @description) RETURNING *;", 
                    sqlParams).Single();
            }
        }

        public Artist UpdateArtists(Artist artist)
        {
            var sqlParams = new NpgsqlParameter[]
            {
                new("id", artist.Id),
                new("name", artist.Name),
                new("dob", artist.DOB),
                new("born", artist.Born ?? (object)DBNull.Value),
                new("languagegroup", artist.LanguageGroup ?? (object)DBNull.Value),
                new("community", artist.Community ?? (object)DBNull.Value),
                new("description", artist.Description ?? (object)DBNull.Value)
            };

            try
            {
                return _repo.ExecuteReader<Artist>(
                    "UPDATE public.artist SET name = @name, dob = @dob, born = @born, languagegroup = @languagegroup, " +
                    "community = @community, description = @description WHERE id = @id RETURNING *;",  
                    sqlParams).Single();
            }
            catch
            {
                return null;
            }
        }

        public void DeleteArtists(int id)
        {
            var sqlParams = new NpgsqlParameter[] { new("id", id) };
            _repo.ExecuteReader<Artist>("DELETE FROM public.artist WHERE id = @id;",  
                    sqlParams);
        }

        public List<Artist> GetArtistsByCommunity(string community)
        {
            var sqlParams = new NpgsqlParameter[] { new("community", community) };
            return _repo.ExecuteReader<Artist>("SELECT * FROM public.artist WHERE community = @community;", 
                    sqlParams);
        }
    }
}