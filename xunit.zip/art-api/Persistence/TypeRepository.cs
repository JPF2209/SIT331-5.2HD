using Npgsql;
using System.Collections.Generic;
using System.Linq;

namespace art_api.Persistence
{
    public class TypeRepository : ITypeDataAccess
    {
        private readonly IRepository _repo;

        public TypeRepository(IRepository repo)
        {
            _repo = repo;
        }

        public List<ArtifactType> GetTypes()
        {
            return _repo.ExecuteReader<ArtifactType>("SELECT * FROM public.type;");
        }

        public ArtifactType GetTypeByID(int id)
        {
            var parameters = new NpgsqlParameter[] { new("id", id) };
            try
            {
                return _repo.ExecuteReader<ArtifactType>(
                    "SELECT * FROM public.type WHERE id = @id;", 
                    parameters
                ).Single();
            }
            catch
            {
                return null;
            }
        }

        public ArtifactType InsertTypes(ArtifactType type)
        {
            var checkParams = new NpgsqlParameter[] { new("title", type.Title) };
            try
            {
                var exists = _repo.ExecuteReader<ArtifactType>(
                    "SELECT * FROM public.type WHERE title = @title;", 
                    checkParams
                );

                if (exists?.Any() == true)
                    return null;
            }
            catch
            {
                // No existing record found, safe to insert
            }

            var sqlParams = new NpgsqlParameter[]
            {
                new("title", type.Title),
                new("description", type.Description ?? (object)DBNull.Value)
            };

            return _repo.ExecuteReader<ArtifactType>(
                "INSERT INTO public.type (title, description) " +
                "VALUES (@title, @description) RETURNING *;", 
                sqlParams
            )?.Single();
        }

        public ArtifactType UpdateTypes(ArtifactType type)
        {
            var sqlParams = new NpgsqlParameter[]
            {
                new("id", type.Id),
                new("title", type.Title),
                new("description", type.Description ?? (object)DBNull.Value)
            };

            try
            {
                return _repo.ExecuteReader<ArtifactType>(
                    "UPDATE public.\"type\" SET title = @title, description = @description " +
                    "WHERE id = @id RETURNING *;", 
                    sqlParams
                ).Single();
            }
            catch
            {
                return null;
            }
        }

        public void DeleteTypes(int id)
        {
            var sqlParams = new NpgsqlParameter[] { new("id", id) };
            _repo.ExecuteReader<ArtifactType>(
                "DELETE FROM public.type WHERE id = @id;",
                sqlParams
            );
        }
    }
}
