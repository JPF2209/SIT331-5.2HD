using Microsoft.AspNetCore.Mvc;
using Npgsql;

namespace art_api.Persistence
{
    public class ExhibitionADO : IExhibitionDataAccess
    {
        private const string CONNECTION_STRING = "Host=localhost;Username=postgres;Password=jpf2209;Database=art";

        public List<Exhibition> GetExhibitions()
        {
            var exhibitions = new List<Exhibition>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM exhibition;", conn);
            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                exhibitions.Add(MapExhibition(dr));
            }
            return exhibitions;
        }

        public Exhibition GetExhibitionByID(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM exhibition WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapExhibition(dr) : null;
        }

        public Exhibition InsertExhibitions(Exhibition newExhibition)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            // Optional: prevent duplicate titles
            using (var checkCmd = new NpgsqlCommand("SELECT COUNT(*) FROM exhibition WHERE title = @title", conn))
            {
                checkCmd.Parameters.AddWithValue("@title", newExhibition.Title);
                var count = (long)checkCmd.ExecuteScalar();
                if (count > 0) return null; // Conflict
            }

            using var cmd = new NpgsqlCommand(
                "INSERT INTO exhibition (title, startdate, enddate, \"description\", \"current\") " +
                "VALUES (@title, @startdate, @enddate, @description, @current) RETURNING *", conn);
            cmd.Parameters.AddWithValue("@title", newExhibition.Title);
            cmd.Parameters.AddWithValue("@startdate", newExhibition.StartDate);
            cmd.Parameters.AddWithValue("@enddate", newExhibition.EndDate);
            cmd.Parameters.AddWithValue("@description", newExhibition.Description ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@current", newExhibition.Current);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapExhibition(dr) : null;
        }

        public Exhibition UpdateExhibitions(Exhibition updatedExhibition)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();

            using var cmd = new NpgsqlCommand(
                "UPDATE exhibition SET title = @title, startdate = @startdate, enddate = @enddate, " +
                "\"description\" = @description, \"current\" = @current WHERE id = @id RETURNING *", conn);
            cmd.Parameters.AddWithValue("@id", updatedExhibition.Id);
            cmd.Parameters.AddWithValue("@title", updatedExhibition.Title);
            cmd.Parameters.AddWithValue("@startdate", updatedExhibition.StartDate);
            cmd.Parameters.AddWithValue("@enddate", updatedExhibition.EndDate);
            cmd.Parameters.AddWithValue("@description", updatedExhibition.Description ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@current", updatedExhibition.Current);

            using var dr = cmd.ExecuteReader();
            return dr.Read() ? MapExhibition(dr) : null;
        }

        public void DeleteExhibitions(int id)
        {
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("DELETE FROM exhibition WHERE id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        public List<Exhibition> GetExhibitionsByCurrent(bool current)
        {
            var exhibitions = new List<Exhibition>();
            using var conn = new NpgsqlConnection(CONNECTION_STRING);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM exhibition WHERE \"current\" = @current", conn);
            cmd.Parameters.AddWithValue("@current", current);
            using var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                exhibitions.Add(MapExhibition(dr));
            }
            return exhibitions;
        }

        private Exhibition MapExhibition(NpgsqlDataReader dr)
        {
            return new Exhibition
            {
                Id = dr.GetInt32(0),
                Title = dr.GetString(1),
                StartDate = dr.GetDateTime(2),
                EndDate = dr.GetDateTime(3),
                Description = dr.IsDBNull(4) ? null : dr.GetString(4),
                Current = dr.GetBoolean(5)
            };
        }
    }
}
