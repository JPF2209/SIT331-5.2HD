using Npgsql;
namespace art_api.Persistence;

public class Repository : IRepository
{
    private const string CONNECTION_STRING = $"Host=localhost;Username=postgres;Password=jpf2209;Database=art";

    public List<T> ExecuteReader<T>(string sqlCommand, NpgsqlParameter[]? dbParams = null) where T : class, new()
    {
        var entities = new List<T>();
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();

        using var cmd = new NpgsqlCommand(sqlCommand, conn);
        if (dbParams is not null)
            cmd.Parameters.AddRange(dbParams);

        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var entity = new T();
            dr.MapTo(entity);  // Flat mapping
            entities.Add(entity);
        }
        return entities;
    }
}
