using System.Collections.Generic;
using art_api;

namespace art_api.Persistence
{
    public interface ITypeDataAccess
    {
        List<ArtifactType> GetTypes();
        ArtifactType GetTypeByID(int id);
        ArtifactType InsertTypes(ArtifactType Type);
        ArtifactType UpdateTypes(ArtifactType Type);
        void DeleteTypes(int id);
    }
}
