using Npgsql;

namespace art_api.Persistence
{
    public class ArtifactRepository : IArtifactDataAccess
    {
        private readonly IRepository _repo;

        public ArtifactRepository(IRepository repo)
        {
            _repo = repo;
        }

        public List<Artifact> GetArtifacts()
        {
            return _repo.ExecuteReader<Artifact>("SELECT * FROM public.artifact;" 
                    );
        }

        public Artifact GetArtifactByID(int id)
        {
            var parameters = new NpgsqlParameter[] { new("id", id) };
            try
            {
                return _repo.ExecuteReader<Artifact>(
                    "SELECT * FROM public.artifact WHERE id = @id;",  
                    parameters).Single();
            }
            catch
            {
                return null;
            }
        }

        public List<Artifact> GetFilteredArtifacts(bool? framed, bool? isNew, bool? staffPick)
        {
            var conditions = new List<string>();
            var parameters = new List<NpgsqlParameter>();

            if (framed.HasValue)
            {
                conditions.Add("framed = @framed");
                parameters.Add(new NpgsqlParameter("@framed", framed.Value));
            }

            if (isNew.HasValue)
            {
                conditions.Add("\"new\" = @new"); // "new" is a reserved word in SQL
                parameters.Add(new NpgsqlParameter("@new", isNew.Value));
            }

            if (staffPick.HasValue)
            {
                conditions.Add("staffpicks = @staffPick");
                parameters.Add(new NpgsqlParameter("@staffPick", staffPick.Value));
            }

            var whereClause = conditions.Count > 0 ? "WHERE " + string.Join(" AND ", conditions) : "";
            var query = $"SELECT * FROM public.artifact {whereClause};";

            return _repo.ExecuteReader<Artifact>(query,  
                     parameters.ToArray());
        }


        public List<Artifact> GetArtifactsByType(string typeTitle)
        {
            var parameters = new NpgsqlParameter[] { new("@typeTitle", typeTitle) };
            string query = @"
                SELECT a.*
                FROM public.artifact a
                JOIN public.type t ON a.typeid = t.id
                WHERE t.title = @typeTitle;";

            return _repo.ExecuteReader<Artifact>(query,  
                     parameters);
        }


        public Artifact InsertArtifacts(Artifact artifact)
        {
            var checkParams = new NpgsqlParameter[] { new("title", artifact.Title) };

            // Step 0: Check for duplicate title
            try
            {
                var exists = _repo.ExecuteReader<Artifact>(
                    "SELECT * FROM public.artifact WHERE title = @title;",
                    checkParams
                )?.FirstOrDefault();

                Console.WriteLine("Artifact already exists with title: " + artifact.Title);
                return null;
            }
            catch
            {
                // Not found, continue
            }

            // Step 1: Validate foreign keys
            int? artistId = _repo.ExecuteReader<Artist>(
                "SELECT id FROM public.artist WHERE id = @id;",
                new NpgsqlParameter[] { new("id", artifact.Artist.Id) }
            ).FirstOrDefault()?.Id;

            int? typeId = _repo.ExecuteReader<ArtifactType>(
                "SELECT id FROM public.type WHERE id = @id;",
                new NpgsqlParameter[] { new("id", artifact.Type.Id) }
            ).FirstOrDefault()?.Id;

            int? exhibitionId = artifact.Exhibition != null
            ? _repo.ExecuteReader<Exhibition>(
                "SELECT id FROM public.exhibition WHERE id = @id;",
                new NpgsqlParameter[] { new("id", artifact.Exhibition.Id) }
            ).FirstOrDefault()?.Id
            : null;


            Console.WriteLine($"ArtistId: {artistId}, TypeId: {typeId}, ExhibitionId: {exhibitionId}");

            // Step 2: Check if any are invalid
            if (artistId == null || typeId == null || exhibitionId == null)
            {
                return null;
            }

            // Step 3: Insert the new artifact
            var sqlParams = new NpgsqlParameter[]
            {
                new("title", artifact.Title),
                new("artistid", artistId ?? (object)DBNull.Value),
                new("productno", artifact.ProductNo),
                new("framed", artifact.Framed),
                new("size", artifact.Size),
                new("medium", artifact.Medium),
                new("price", artifact.Price),
                new("saleprice", artifact.SalePrice ?? (object)DBNull.Value),
                new("onsale", artifact.OnSale),
                new("typeid", typeId ?? (object)DBNull.Value),
                new("colour", artifact.Colour),
                new("shape", artifact.Shape),
                new("new", artifact.New),
                new("staffpicks", artifact.StaffPicks),
                new("exhibitionid", exhibitionId ?? (object)DBNull.Value)
            };

            var inserted = _repo.ExecuteReader<Artifact>(
                @"INSERT INTO public.artifact (
                    title, artistid, productno, framed, size, medium, price, saleprice, 
                    onsale, typeid, colour, shape, new, staffpicks, exhibitionid
                ) VALUES (
                    @title, @artistid, @productno, @framed, @size, @medium, @price, @saleprice, 
                    @onsale, @typeid, @colour, @shape, @new, @staffpicks, @exhibitionid
                ) RETURNING *;",
                dbParams: sqlParams
            )?.FirstOrDefault();

            return inserted;
        }


        public Artifact UpdateArtifacts(int id, Artifact artifact)
        {
            // Try to find the Artist
            var artistResults = _repo.ExecuteReader<Artist>(
                "SELECT * FROM public.artist WHERE id = @id;",
                new NpgsqlParameter[] { new("id", artifact.Artist.Id) }
            );
            int? artistId = artistResults?.FirstOrDefault()?.Id;

            // Try to find the Type
            var typeResults = _repo.ExecuteReader<ArtifactType>(
                "SELECT * FROM public.type WHERE id = @id;",
                new NpgsqlParameter[] { new("id", artifact.Type.Id) }
            );
            int? typeId = typeResults?.FirstOrDefault()?.Id;

            // Try to find the Exhibition (only if Exhibition is provided)
            int? exhibitionId = null;

            if (artifact.Exhibition != null)
            {
                var exhibitionResults = _repo.ExecuteReader<Exhibition>(
                    "SELECT * FROM public.exhibition WHERE id = @id;",
                    new NpgsqlParameter[] { new("id", artifact.Exhibition.Id) }
                );

                exhibitionId = exhibitionResults?.FirstOrDefault()?.Id;
            }

            var sqlParams = new NpgsqlParameter[]
            {
                new("id", id),
                new("title", artifact.Title),
                new("artistid", artistId ?? (object)DBNull.Value),
                new("productno", artifact.ProductNo),
                new("framed", artifact.Framed),
                new("size", artifact.Size),
                new("medium", artifact.Medium),
                new("price", artifact.Price),
                new("saleprice", artifact.SalePrice ?? (object)DBNull.Value),
                new("onsale", artifact.OnSale),
                new("typeid", typeId ?? (object)DBNull.Value),
                new("colour", artifact.Colour),
                new("shape", artifact.Shape),
                new("new", artifact.New),
                new("staffpicks", artifact.StaffPicks),
                new("exhibitionid", exhibitionId ?? (object)DBNull.Value)
            };

            var updated = _repo.ExecuteReader<Artifact>(
                @"UPDATE public.artifact SET 
                    title = @title,
                    artistid = @artistid,
                    productno = @productno,
                    framed = @framed,
                    size = @size,
                    medium = @medium,
                    price = @price,
                    saleprice = @saleprice,
                    onsale = @onsale,
                    typeid = @typeid,
                    colour = @colour,
                    shape = @shape,
                    new = @new,
                    staffpicks = @staffpicks,
                    exhibitionid = @exhibitionid
                WHERE id = @id
                RETURNING *;",
                dbParams: sqlParams
            )?.FirstOrDefault();

            return updated;

        }

        public void DeleteArtifacts(int id)
        {
            var sqlParams = new NpgsqlParameter[] { new("id", id) };
            _repo.ExecuteReader<Artifact>("DELETE FROM public.artifact WHERE id = @id;", 
                     sqlParams);
        }
    }
}
