using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using Npgsql;
using art_api;

public class ArtistRepositoryTests
{
    private readonly Mock<IRepository> _mockRepo;
    private readonly ArtistRepository _artistRepo;

    public ArtistRepositoryTests()
    {
        _mockRepo = new Mock<IRepository>();
        _artistRepo = new ArtistRepository(_mockRepo.Object); // ✅ Inject the mock directly
    }

    [Fact]
    public void GetArtists_ReturnsAllArtists()
    {
        var artists = new List<Artist>
        {
            new Artist { Id = 1, Name = "Test Artist", DOB = 1980, Born = "Darwin, NT", LanguageGroup = "Group", Community = "Community", Description = "Description" }
        };

        _mockRepo.Setup(r => r.ExecuteReader<Artist>("SELECT * FROM public.artist;", It.IsAny<NpgsqlParameter[]>()))
         .Returns(artists);

        var result = _artistRepo.GetArtists();

        Assert.Single(result);
        Assert.Equal("Test Artist", result[0].Name);
    }

    [Fact]
    public void GetArtistByID_ReturnsCorrectArtist()
    {
        var artist = new Artist { Id = 1, Name = "Test" };
        var parameters = new NpgsqlParameter[] { new("id", 1) };

        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "SELECT * FROM public.artist WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => p.Length == 1 && (int)p[0].Value == artist.Id)
        ))
        .Returns(new List<Artist> { artist });


        var result = _artistRepo.GetArtistByID(1);

        Assert.NotNull(result);
        Assert.Equal("Test", result.Name);
    }

    [Fact]
    public void GetArtistByID_ReturnsNullIfNotFound()
    {
        var parameters = new NpgsqlParameter[] { new("id", 99) };
        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "SELECT * FROM public.artist WHERE id = @id;", parameters))
            .Throws(new InvalidOperationException());

        var result = _artistRepo.GetArtistByID(99);

        Assert.Null(result);
    }
    
    [Fact]
    public void InsertArtists_InsertsAndReturnsArtist_WhenNotExists()
    {
        var newArtist = new Artist { Name = "New", DOB = 1990 };
        
        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "SELECT * FROM public.artist WHERE name = @name;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("New"))))
            .Throws(new InvalidOperationException()); // simulate not found

        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            It.Is<string>(sql => sql.StartsWith("INSERT INTO")),
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("New"))))
            .Returns(new List<Artist> { newArtist });

        var result = _artistRepo.InsertArtists(newArtist);

        Assert.NotNull(result);
        Assert.Equal("New", result.Name);
    }

    [Fact]
    public void InsertArtists_ReturnsNull_WhenArtistAlreadyExists()
    {
        var existingArtist = new Artist { Name = "Existing", DOB = 1980 };

        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "SELECT * FROM public.artist WHERE name = @name;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Existing"))))
            .Returns(new List<Artist> { existingArtist });

        var result = _artistRepo.InsertArtists(existingArtist);

        Assert.Null(result);
    }

    [Fact]
    public void UpdateArtists_UpdatesAndReturnsArtist()
    {
        var artistToUpdate = new Artist { Id = 1, Name = "Updated", DOB = 1995 };

        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            It.Is<string>(s => s.StartsWith("UPDATE")),
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)))
            .Returns(new List<Artist> { artistToUpdate });

        var result = _artistRepo.UpdateArtists(artistToUpdate);

        Assert.NotNull(result);
        Assert.Equal("Updated", result.Name);
    }

    [Fact]
    public void UpdateArtists_ReturnsNull_OnException()
    {
        var artist = new Artist { Id = 99, Name = "Broken", DOB = 1980 };

        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            It.Is<string>(s => s.StartsWith("UPDATE")),
            It.IsAny<NpgsqlParameter[]>()))
            .Throws(new Exception());

        var result = _artistRepo.UpdateArtists(artist);

        Assert.Null(result);
    }

    [Fact]
    public void DeleteArtists_DeletesArtist()
    {
        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "DELETE FROM public.artist WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)))
            .Returns(new List<Artist>());

        _artistRepo.DeleteArtists(1);

        _mockRepo.Verify(r => r.ExecuteReader<Artist>(
            "DELETE FROM public.artist WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)), Times.Once);
    }

    [Fact]
    public void GetArtistsByCommunity_ReturnsMatchingArtists()
    {
        var community = "Anangu";
        var expected = new List<Artist> {
            new Artist { Id = 1, Name = "Alice", Community = "Anangu" }
        };

        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "SELECT * FROM public.artist WHERE community = @community;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals(community))))
            .Returns(expected);

        var result = _artistRepo.GetArtistsByCommunity(community);

        Assert.Single(result);
        Assert.Equal("Alice", result[0].Name);
    }

}

