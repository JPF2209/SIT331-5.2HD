using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using Npgsql;
using art_api;

public class ArtifactRepositoryTests
{
    private List<Artifact> _artifacts = new List<Artifact>
    {
        new Artifact
        {
            Id = 1,
            Title = "Exhibit A",
            ArtistId = 101,
            Artist = new Artist { Id = 101, Name = "Alice Walker" },
            ProductNo = "A001",
            Framed = true,
            Size = "24x36",
            Medium = "Oil on Canvas",
            Price = 1200.00,
            SalePrice = 1000.00,
            OnSale = true,
            TypeId = 1,
            Type = new ArtifactType { Id = 1, Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Blue",
            Shape = "Rectangle",
            New = false,
            StaffPicks = true,
            ExhibitionId = 201,
            Exhibition = new Exhibition { Id = 201, Title = "Winter Collection" }
        },
        new Artifact
        {
            Id = 2,
            Title = "Urban Dream",
            ArtistId = 102,
            Artist = new Artist { Id = 102, Name = "Ben Carter" },
            ProductNo = "A002",
            Framed = false,
            Size = "18x24",
            Medium = "Acrylic",
            Price = 800.00,
            SalePrice = null,
            OnSale = false,
            TypeId = 2,
            Type = new ArtifactType { Id = 2, Title = "Sketch", Description = "Pencil and ink sketches" },
            Colour = "Monochrome",
            Shape = "Square",
            New = true,
            StaffPicks = false,
            ExhibitionId = null,
            Exhibition = null
        },
        new Artifact
        {
            Id = 3,
            Title = "Sunset Symphony",
            ArtistId = 103,
            Artist = new Artist { Id = 103, Name = "Clara Zhou" },
            ProductNo = "A003",
            Framed = true,
            Size = "30x40",
            Medium = "Watercolor",
            Price = 1500.00,
            SalePrice = 1350.00,
            OnSale = true,
            TypeId = 1,
            Type = new ArtifactType { Id = 1, Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Orange",
            Shape = "Oval",
            New = true,
            StaffPicks = true,
            ExhibitionId = 202,
            Exhibition = new Exhibition { Id = 202, Title = "Spring Showcase" }
        },
        new Artifact
        {
            Id = 4,
            Title = "Fragmented Reflections",
            ArtistId = 104,
            Artist = new Artist { Id = 104, Name = "David Lin" },
            ProductNo = "A004",
            Framed = false,
            Size = "20x30",
            Medium = "Mixed Media",
            Price = 2000.00,
            SalePrice = null,
            OnSale = false,
            TypeId = 3,
            Type = new ArtifactType { Id = 3, Title = "Installation", Description = "3D artistic installations" },
            Colour = "Metallic",
            Shape = "Irregular",
            New = false,
            StaffPicks = false,
            ExhibitionId = null,
            Exhibition = null
        }
    };

    private readonly Mock<IRepository> _mockRepo;
    private readonly ArtifactRepository _artifactRepo;

    public ArtifactRepositoryTests()
    {
        _mockRepo = new Mock<IRepository>();
        _artifactRepo = new ArtifactRepository(_mockRepo.Object);
    }

    [Fact]
    public void GetArtifacts_ReturnsAllArtifacts()
    {
        var artifacts = new List<Artifact>
        {
            new Artifact
            {
                Id = 1,
                Title = "Exhibit A",
                ArtistId = 101,
                Artist = new Artist { Id = 101, Name = "Alice Walker" },
                ProductNo = "A001",
                Framed = true,
                Size = "24x36",
                Medium = "Oil on Canvas",
                Price = 1200.00,
                SalePrice = 1000.00,
                OnSale = true,
                TypeId = 1,
                Type = new ArtifactType { Id = 1, Title = "Painting", Description = "Pigments on canvas or wood" },
                Colour = "Blue",
                Shape = "Rectangle",
                New = false,
                StaffPicks = true,
                ExhibitionId = 201,
                Exhibition = new Exhibition { Id = 201, Title = "Winter Collection" }
            },
            new Artifact
            {
                Id = 2,
                Title = "Urban Dream",
                ArtistId = 102,
                Artist = new Artist { Id = 102, Name = "Ben Carter" },
                ProductNo = "A002",
                Framed = false,
                Size = "18x24",
                Medium = "Acrylic",
                Price = 800.00,
                SalePrice = null,
                OnSale = false,
                TypeId = 2,
                Type = new ArtifactType { Id = 2, Title = "Sketch", Description = "Pencil and ink sketches" },
                Colour = "Monochrome",
                Shape = "Square",
                New = true,
                StaffPicks = false,
                ExhibitionId = null,
                Exhibition = null
            }
        };

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            "SELECT * FROM public.artifact;", It.IsAny<NpgsqlParameter[]>()))
            .Returns(artifacts);

        var result = _artifactRepo.GetArtifacts();

        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.Collection(result,
            e => Assert.Equal("Exhibit A", e.Title),
            e => Assert.Equal("Urban Dream", e.Title));
    }


    [Fact]
    public void GetArtifactByID_ReturnsCorrectArtifact()
    {
        var artifact = new Artifact
        {
            Id = 1,
            Title = "Exhibit A",
            ArtistId = 101,
            Artist = new Artist { Id = 101, Name = "Alice Walker" },
            ProductNo = "A001",
            Framed = true,
            Size = "24x36",
            Medium = "Oil on Canvas",
            Price = 1200.00,
            SalePrice = 1000.00,
            OnSale = true,
            TypeId = 1,
            Type = new ArtifactType { Id = 1, Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Blue",
            Shape = "Rectangle",
            New = false,
            StaffPicks = true,
            ExhibitionId = 201,
            Exhibition = new Exhibition { Id = 201, Title = "Winter Collection" }
        };
        var parameters = new NpgsqlParameter[] { new("id", 1) };

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            "SELECT * FROM public.artifact WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => p.Length == 1 && (int)p[0].Value == artifact.Id)
        ))
        .Returns(new List<Artifact> { artifact });


        var result = _artifactRepo.GetArtifactByID(1);

        Assert.NotNull(result);
        Assert.Equal("Exhibit A", result.Title);
    }

    [Fact]
    public void GetArtifactByID_ReturnsNullIfNotFound()
    {
        var parameters = new NpgsqlParameter[] { new("id", 99) };
        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            "SELECT * FROM public.artifact WHERE id = @id;", parameters))
            .Throws(new InvalidOperationException());

        var result = _artifactRepo.GetArtifactByID(99);

        Assert.Null(result);
    }
    
    [Fact]
    public void InsertArtifacts_InsertsAndReturnsArtifact_WhenNotExists()
    {
        // Arrange
        var newArtifact = new Artifact
        {
            Id = 3,
            Title = "Sunset Symphony",
            ArtistId = 103,
            Artist = new Artist { Id = 103, Name = "Clara Zhou" },
            ProductNo = "A003",
            Framed = true,
            Size = "30x40",
            Medium = "Watercolor",
            Price = 1500.00,
            SalePrice = 1350.00,
            OnSale = true,
            TypeId = 1,
            Type = new ArtifactType { Id = 1, Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Orange",
            Shape = "Oval",
            New = true,
            StaffPicks = true,
            ExhibitionId = 202,
            Exhibition = new Exhibition { Id = 202, Title = "Spring Showcase" }
        };

        // Simulate "artifact with title doesn't exist"
        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            "SELECT * FROM public.artifact WHERE title = @title;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Sunset Symphony"))))
            .Throws(new InvalidOperationException());

        // Simulate FK check: artist exists
        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "SELECT id FROM public.artist WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 103)))
            .Returns(new List<Artist> { new Artist { Id = 103 } });


        // Simulate FK check: type exists
        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "SELECT id FROM public.type WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)))
            .Returns(new List<ArtifactType> { new ArtifactType { Id = 1 } });

        // Simulate FK check: exhibition exists
        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "SELECT id FROM public.exhibition WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 202)))
            .Returns(new List<Exhibition> { new Exhibition { Id = 202 } });

        // Simulate successful insert returning the inserted object
        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(sql => sql.StartsWith("INSERT INTO")),
            It.IsAny<NpgsqlParameter[]>()))
            .Returns(new List<Artifact> { newArtifact });

        // Act
        var result = _artifactRepo.InsertArtifacts(newArtifact);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Sunset Symphony", result.Title);
    }


    [Fact]
    public void InsertArtifacts_ReturnsNull_WhenArtifactAlreadyExists()
    {
        var existingArtifact = new Artifact
        {
            Id = 3,
            Title = "Sunset Symphony",
            ArtistId = 103,
            Artist = new Artist { Id = 103, Name = "Clara Zhou" },
            ProductNo = "A003",
            Framed = true,
            Size = "30x40",
            Medium = "Watercolor",
            Price = 1500.00,
            SalePrice = 1350.00,
            OnSale = true,
            TypeId = 1,
            Type = new ArtifactType { Id = 1, Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Orange",
            Shape = "Oval",
            New = true,
            StaffPicks = true,
            ExhibitionId = 202,
            Exhibition = new Exhibition { Id = 202, Title = "Spring Showcase" }
        };

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            "SELECT * FROM public.artifact WHERE title = @title;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Sunset Symphony"))))
            .Returns(new List<Artifact> { existingArtifact });

        var result = _artifactRepo.InsertArtifacts(existingArtifact);

        Assert.Null(result);
    }

    [Fact]
    public void UpdateArtifacts_UpdatesAndReturnsArtifact()
    {
        var updatedArtifact = new Artifact
        {
            Id = 4,
            Title = "Fragmented Reflections",
            ArtistId = 104,
            Artist = new Artist { Id = 104, Name = "David Lin" },
            ProductNo = "A004",
            Framed = false,
            Size = "20x30",
            Medium = "Mixed Media",
            Price = 2000.00,
            SalePrice = null,
            OnSale = false,
            TypeId = 3,
            Type = new ArtifactType { Id = 3, Title = "Installation", Description = "3D artistic installations" },
            Colour = "Metallic",
            Shape = "Irregular",
            New = false,
            StaffPicks = false,
            ExhibitionId = null,
            Exhibition = null
        };

        // Simulate "artifact with title doesn't exist"
        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            "SELECT * FROM public.artifact WHERE title = @title;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Fragmented Reflections"))))
            .Throws(new InvalidOperationException());

        // Simulate FK check: artist exists
        _mockRepo.Setup(r => r.ExecuteReader<Artist>(
            "SELECT id FROM public.artist WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 104)))
            .Returns(new List<Artist> { new Artist { Id = 104 } });


        // Simulate FK check: type exists
        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "SELECT id FROM public.type WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 3)))
            .Returns(new List<ArtifactType> { new ArtifactType { Id = 3 } });


        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(s => s.StartsWith("UPDATE")),
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 4)))
            .Returns(new List<Artifact> { updatedArtifact });

        var result = _artifactRepo.UpdateArtifacts(updatedArtifact.Id,updatedArtifact);

        Assert.NotNull(result);
        Assert.Equal("Fragmented Reflections", result.Title);
    }

    [Fact]
    public void UpdateArtifacts_ReturnsNull_OnException()
    {
        var artifact = new Artifact
        {
            Id = 4,
            Title = "Fragmented Reflections",
            ArtistId = 104,
            Artist = new Artist { Id = 104, Name = "David Lin" },
            ProductNo = "A004",
            Framed = false,
            Size = "20x30",
            Medium = "Mixed Media",
            Price = 2000.00,
            SalePrice = null,
            OnSale = false,
            TypeId = 3,
            Type = new ArtifactType { Id = 3, Title = "Installation", Description = "3D artistic installations" },
            Colour = "Metallic",
            Shape = "Irregular",
            New = false,
            StaffPicks = false,
            ExhibitionId = null,
            Exhibition = null
        };

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(sql => sql.StartsWith("UPDATE public.artifact SET")),
            It.IsAny<NpgsqlParameter[]>()
        )).Returns(new List<Artifact>());


        var result = _artifactRepo.UpdateArtifacts(artifact.Id, artifact);

        Assert.Null(result);
    }

    [Fact]
    public void DeleteArtifacts_DeletesArtifact()
    {
        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            "DELETE FROM public.artifact WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)))
            .Returns(new List<Artifact>());

        _artifactRepo.DeleteArtifacts(1);

        _mockRepo.Verify(r => r.ExecuteReader<Artifact>(
            "DELETE FROM public.artifact WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)), Times.Once);
    }

    [Fact]
    public void GetArtifactsByTypes_ReturnsMatchingTypes()
    {
        var type = new ArtifactType { Id = 3, Title = "Installation", Description = "3D artistic installations" };
        var expected = new List<Artifact>
        {
            new Artifact
            {
                Id = 4,
                Title = "Fragmented Reflections",
                ArtistId = 104,
                Artist = new Artist { Id = 104, Name = "David Lin" },
                ProductNo = "A004",
                Framed = false,
                Size = "20x30",
                Medium = "Mixed Media",
                Price = 2000.00,
                SalePrice = null,
                OnSale = false,
                TypeId = 3,
                Type = new ArtifactType { Id = 3, Title = "Installation", Description = "3D artistic installations" },
                Colour = "Metallic",
                Shape = "Irregular",
                New = false,
                StaffPicks = false,
                ExhibitionId = null,
                Exhibition = null
            }
        };

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(sql => sql.Contains("t.title = @typeTitle")),
            It.Is<NpgsqlParameter[]>(p =>
                p != null &&
                p.Length == 1 &&
                p[0].ParameterName == "@typeTitle" &&
                (string)p[0].Value == type.Title)))
            .Returns(expected);

        var result = _artifactRepo.GetArtifactsByType(type.Title);

        Assert.NotNull(result);
        Assert.Single(result);
        Assert.Equal("Fragmented Reflections", result[0].Title);
        Assert.Equal("Installation", result[0].Type.Title);
    }

    [Fact]
    public void GetFilteredArtifacts_FramedTrue_ReturnsFramedArtifacts()
    {
        var expected = _artifacts.Where(a => a.Framed).ToList();

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(q => q.Contains("framed = @framed") && !q.Contains("@new") && !q.Contains("@staffPick")),
            It.Is<NpgsqlParameter[]>(p =>
                p.Length == 1 &&
                p[0].ParameterName == "@framed" &&
                (bool)p[0].Value == true)))
            .Returns(expected);

        var result = _artifactRepo.GetFilteredArtifacts(true, null, null);

        Assert.Equal(2, result.Count);
        Assert.All(result, a => Assert.True(a.Framed));
    }

    [Fact]
    public void GetFilteredArtifacts_SpecificCombo_ReturnsMatchingArtifact()
    {
        var expected = _artifacts
            .Where(a => !a.Framed && a.New && !a.StaffPicks)
            .ToList();

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(q => 
                q.Contains("framed = @framed") &&
                q.Contains("\"new\" = @new") &&
                q.Contains("staffpicks = @staffPick")),
            It.Is<NpgsqlParameter[]>(p =>
                p.Length == 3 &&
                (bool)p.First(x => x.ParameterName == "@framed").Value == false &&
                (bool)p.First(x => x.ParameterName == "@new").Value == true &&
                (bool)p.First(x => x.ParameterName == "@staffPick").Value == false)))
            .Returns(expected);

        var result = _artifactRepo.GetFilteredArtifacts(false, true, false);

        Assert.Single(result);
        Assert.Equal("Urban Dream", result[0].Title);
    }

    [Fact]
    public void GetFilteredArtifacts_StaffPickTrue_ReturnsStaffPicks()
    {
        var expected = _artifacts.Where(a => a.StaffPicks).ToList();

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(q => q.Contains("staffpicks = @staffPick")),
            It.Is<NpgsqlParameter[]>(p =>
                p.Length == 1 &&
                p[0].ParameterName == "@staffPick" &&
                (bool)p[0].Value == true)))
            .Returns(expected);

        var result = _artifactRepo.GetFilteredArtifacts(null, null, true);

        Assert.Equal(2, result.Count);
        Assert.All(result, a => Assert.True(a.StaffPicks));
    }

    [Fact]
    public void GetFilteredArtifacts_NoFilters_ReturnsAllArtifacts()
    {
        var expected = _artifacts;

        _mockRepo.Setup(r => r.ExecuteReader<Artifact>(
            It.Is<string>(q => !q.Contains("WHERE")),
            It.Is<NpgsqlParameter[]>(p => p.Length == 0)))
            .Returns(expected);

        var result = _artifactRepo.GetFilteredArtifacts(null, null, null);

        Assert.Equal(4, result.Count);
    }


}