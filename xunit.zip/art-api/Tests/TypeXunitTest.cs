using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using Npgsql;
using art_api;

public class TypeRepositoryTests
{
    private readonly Mock<IRepository> _mockRepo;
    private readonly TypeRepository _typeRepo;

    public TypeRepositoryTests()
    {
        _mockRepo = new Mock<IRepository>();
        _typeRepo = new TypeRepository(_mockRepo.Object);
    }


    [Fact]
    public void GetTypes_ReturnsAllTypes()
    {
        var types = new List<ArtifactType>
        {
            new ArtifactType
            {
                Id = 1,
                Title = "Sculpture",
                Description = "Three-dimensional artworks carved or molded from various materials."
            },
            new ArtifactType
            {
                Id = 2,
                Title = "Painting",
                Description = "Artworks created using pigments on a surface such as canvas or wood."
            }
        };

        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "SELECT * FROM public.type;", It.IsAny<NpgsqlParameter[]>()))
            .Returns(types);

        var result = _typeRepo.GetTypes();

        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.Collection(result,
            e => Assert.Equal("Sculpture", e.Title),
            e => Assert.Equal("Painting", e.Title));
    }


    [Fact]
    public void GetTypeByID_ReturnsCorrectType()
    {
        var type = new ArtifactType
        {
            Id = 1,
            Title = "Sculpture",
            Description = "Three-dimensional artworks carved or molded from various materials."
        };
        var parameters = new NpgsqlParameter[] { new("id", 1) };

        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "SELECT * FROM public.type WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => p.Length == 1 && (int)p[0].Value == type.Id)
        ))
        .Returns(new List<ArtifactType> { type });


        var result = _typeRepo.GetTypeByID(1);

        Assert.NotNull(result);
        Assert.Equal("Sculpture", result.Title);
    }

    [Fact]
    public void GetTypeByID_ReturnsNullIfNotFound()
    {
        var parameters = new NpgsqlParameter[] { new("id", 99) };
        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "SELECT * FROM public.type WHERE id = @id;", parameters))
            .Throws(new InvalidOperationException());

        var result = _typeRepo.GetTypeByID(99);

        Assert.Null(result);
    }
    
    [Fact]
    public void InsertTypes_InsertsAndReturnsType_WhenNotExists()
    {
        var newType = new ArtifactType
        {
            Id = 3,
            Title = "Textile",
            Description = "Art made with woven, knitted, or printed fabrics, often with cultural significance."
        };
        
        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "SELECT * FROM public.type WHERE title = @title;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Textile"))))
            .Throws(new InvalidOperationException()); // simulate not found

        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            It.Is<string>(sql => sql.StartsWith("INSERT INTO")),
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Textile"))))
            .Returns(new List<ArtifactType> { newType });

        var result = _typeRepo.InsertTypes(newType);

        Assert.NotNull(result);
        Assert.Equal("Textile", result.Title);
    }

    [Fact]
    public void InsertTypes_ReturnsNull_WhenTypeAlreadyExists()
    {
        var existingType = new ArtifactType
        {
            Id = 3,
            Title = "Textile",
            Description = "Art made with woven, knitted, or printed fabrics, often with cultural significance."
        };

        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "SELECT * FROM public.type WHERE title = @title;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Textile"))))
            .Returns(new List<ArtifactType> { existingType });

        var result = _typeRepo.InsertTypes(existingType);

        Assert.Null(result);
    }

    [Fact]
    public void UpdateTypes_UpdatesAndReturnsType()
    {
        var updatedType = new ArtifactType
        {
            Id = 4,
            Title = "Ceramics",
            Description = "Objects made from clay and hardened by heat, including pottery and tiles."
        };

        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            It.Is<string>(s => s.StartsWith("UPDATE")),
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 4)))
            .Returns(new List<ArtifactType> { updatedType });

        var result = _typeRepo.UpdateTypes(updatedType);

        Assert.NotNull(result);
        Assert.Equal("Ceramics", result.Title);
    }

    [Fact]
    public void UpdateTypes_ReturnsNull_OnException()
    {
        var type = new ArtifactType
        {
            Id = 4,
            Title = "Ceramics",
            Description = "Objects made from clay and hardened by heat, including pottery and tiles."
        };
        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            It.Is<string>(s => s.StartsWith("UPDATE")),
            It.IsAny<NpgsqlParameter[]>()))
            .Throws(new Exception());

        var result = _typeRepo.UpdateTypes(type);

        Assert.Null(result);
    }

    [Fact]
    public void DeleteTypes_DeletesType()
    {
        _mockRepo.Setup(r => r.ExecuteReader<ArtifactType>(
            "DELETE FROM public.type WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)))
            .Returns(new List<ArtifactType>());

        _typeRepo.DeleteTypes(1);

        _mockRepo.Verify(r => r.ExecuteReader<ArtifactType>(
            "DELETE FROM public.type WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)), Times.Once);
    }
}