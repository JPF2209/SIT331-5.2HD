using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using Npgsql;
using art_api;

public class ExhibitionRepositoryTests
{
    private readonly Mock<IRepository> _mockRepo;
    private readonly ExhibitionRepository _exhibitionRepo;

    public ExhibitionRepositoryTests()
    {
        _mockRepo = new Mock<IRepository>();
        _exhibitionRepo = new ExhibitionRepository(_mockRepo.Object);
    }


    [Fact]
    public void GetExhibitions_ReturnsAllExhibitions()
    {
        var exhibitions = new List<Exhibition>
        {
            new Exhibition
            {
                Id = 1,
                Title = "Exhibit A",
                StartDate = new DateTime(2024, 1, 1),
                EndDate = new DateTime(2024, 6, 1),
                Description = "Test A",
                Current = false
            },
            new Exhibition
            {
                Id = 2,
                Title = "Exhibit B",
                StartDate = new DateTime(2024, 7, 1),
                EndDate = new DateTime(2024, 12, 1),
                Description = "Test B",
                Current = true
            }
        };

        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "SELECT * FROM public.exhibition;", It.IsAny<NpgsqlParameter[]>()))
            .Returns(exhibitions);

        var result = _exhibitionRepo.GetExhibitions();

        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.Collection(result,
            e => Assert.Equal("Exhibit A", e.Title),
            e => Assert.Equal("Exhibit B", e.Title));
    }


    [Fact]
    public void GetExhibitionByID_ReturnsCorrectExhibition()
    {
        var exhibition = new Exhibition
        {
            Id = 1,
            Title = "Indigenous Art Now",
            StartDate = new DateTime(2025, 1, 15),
            EndDate = new DateTime(2025, 6, 30),
            Description = "A showcase of contemporary Indigenous artworks.",
            Current = true
        };
        var parameters = new NpgsqlParameter[] { new("id", 1) };

        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "SELECT * FROM public.exhibition WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => p.Length == 1 && (int)p[0].Value == exhibition.Id)
        ))
        .Returns(new List<Exhibition> { exhibition });


        var result = _exhibitionRepo.GetExhibitionByID(1);

        Assert.NotNull(result);
        Assert.Equal("Indigenous Art Now", result.Title);
    }

    [Fact]
    public void GetExhibitionByID_ReturnsNullIfNotFound()
    {
        var parameters = new NpgsqlParameter[] { new("id", 99) };
        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "SELECT * FROM public.exhibition WHERE id = @id;", parameters))
            .Throws(new InvalidOperationException());

        var result = _exhibitionRepo.GetExhibitionByID(99);

        Assert.Null(result);
    }
    
    [Fact]
    public void InsertExhibitions_InsertsAndReturnsExhibition_WhenNotExists()
    {
        var newExhibition = new Exhibition {
            Title = "Ancient Dreamings",
            StartDate = new DateTime(2024, 3, 1),
            EndDate = new DateTime(2024, 8, 1),
            Description = "Artifacts and interpretations from ancient traditions.",
            Current = false
        };
        
        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "SELECT * FROM public.exhibition WHERE title = @title;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Ancient Dreamings"))))
            .Throws(new InvalidOperationException()); // simulate not found

        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            It.Is<string>(sql => sql.StartsWith("INSERT INTO")),
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Ancient Dreamings"))))
            .Returns(new List<Exhibition> { newExhibition });

        var result = _exhibitionRepo.InsertExhibitions(newExhibition);

        Assert.NotNull(result);
        Assert.Equal("Ancient Dreamings", result.Title);
    }

    [Fact]
    public void InsertExhibitions_ReturnsNull_WhenExhibitionAlreadyExists()
    {
        var existingExhibition = new Exhibition {
            Title = "Ancient Dreamings",
            StartDate = new DateTime(2024, 3, 1),
            EndDate = new DateTime(2024, 8, 1),
            Description = "Artifacts and interpretations from ancient traditions.",
            Current = false
        };

        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "SELECT * FROM public.exhibition WHERE title = @title;",
            It.Is<NpgsqlParameter[]>(p => p[0].Value.Equals("Ancient Dreamings"))))
            .Returns(new List<Exhibition> { existingExhibition });

        var result = _exhibitionRepo.InsertExhibitions(existingExhibition);

        Assert.Null(result);
    }

    [Fact]
    public void UpdateExhibitions_UpdatesAndReturnsExhibition()
    {
        var updatedExhibition = new Exhibition {
            Id = 3,
            Title = "Updated",
            StartDate = new DateTime(2025, 4, 10),
            EndDate = new DateTime(2025, 12, 31),
            Description = "Updated description.",
            Current = true
        };

        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            It.Is<string>(s => s.StartsWith("UPDATE")),
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 3)))
            .Returns(new List<Exhibition> { updatedExhibition });

        var result = _exhibitionRepo.UpdateExhibitions(updatedExhibition);

        Assert.NotNull(result);
        Assert.Equal("Updated", result.Title);
    }

    [Fact]
    public void UpdateExhibitions_ReturnsNull_OnException()
    {
        var exhibition = new Exhibition { Id = 99, 
            Title = "Voices from the Land",
            StartDate = new DateTime(2025, 4, 10),
            EndDate = new DateTime(2025, 12, 31),
            Description = "Environmental themes through First Nations perspectives.",
            Current = true
        };

        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            It.Is<string>(s => s.StartsWith("UPDATE")),
            It.IsAny<NpgsqlParameter[]>()))
            .Throws(new Exception());

        var result = _exhibitionRepo.UpdateExhibitions(exhibition);

        Assert.Null(result);
    }

    [Fact]
    public void DeleteExhibitions_DeletesExhibition()
    {
        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "DELETE FROM public.exhibition WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)))
            .Returns(new List<Exhibition>());

        _exhibitionRepo.DeleteExhibitions(1);

        _mockRepo.Verify(r => r.ExecuteReader<Exhibition>(
            "DELETE FROM public.exhibition WHERE id = @id;",
            It.Is<NpgsqlParameter[]>(p => (int)p[0].Value == 1)), Times.Once);
    }

    [Fact]
    public void GetExhibitionsByCurrent_ReturnsMatchingExhibitions()
    {
        // Arrange
        bool current = true;
        var expected = new List<Exhibition>
        {
            new Exhibition
            {
                Id = 1,
                Title = "Modern Art",
                StartDate = new DateTime(2024, 1, 1),
                EndDate = new DateTime(2024, 12, 31),
                Description = "A year-long modern art exhibition.",
                Current = true
            }
        };

        _mockRepo.Setup(r => r.ExecuteReader<Exhibition>(
            "SELECT * FROM public.exhibition WHERE \"current\" = @current;",
            It.Is<NpgsqlParameter[]>(p => (bool)p[0].Value == current)))
            .Returns(expected);

        // Act
        var result = _exhibitionRepo.GetExhibitionsByCurrent(current);

        // Assert
        Assert.Single(result);
        Assert.True(result[0].Current);
        Assert.Equal("Modern Art", result[0].Title);
    }
}

