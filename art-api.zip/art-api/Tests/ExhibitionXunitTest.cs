using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using art_api.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using art_api.Settings;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;

public class ExhibitionRepositoryTests
{
    private readonly ExhibitionRepository _exhibitionRepo;

    // Test for returning all exhibitions
    [Fact]
    public async Task GetExhibitions_ReturnsAllExhibitions()
    {
        // Arrange
        var exhibitions = new List<Exhibition>
        {
            new Exhibition {
                Id = "1",
                Title = "Exhibit A",
                StartDate = new DateTime(2024, 1, 1),
                EndDate = new DateTime(2024, 6, 1),
                Description = "Test A",
                Current = false
            }
        };

        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(exhibitions);
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);

        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetAllAsync();

        // Assert
        Assert.Single(result);
        Assert.Equal("Exhibit A", result[0].Title);
    }

    // Test for returning exhibitions by id
    [Fact]
    public async Task GetExhibitionByID_ReturnsCorrectExhibition()
    {
        // Arrange
        var exhibition = new Exhibition 
        {
            Id = "1",
            Title = "Exhibit A",
            StartDate = new DateTime(2024, 1, 1),
            EndDate = new DateTime(2024, 6, 1),
            Description = "Test A",
            Current = false
        };
        var exhibitionList = new List<Exhibition> { exhibition };

        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(exhibitionList);  // Must return IEnumerable<Exhibition>
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration
        
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("1");  // ✅ Use `repo` and await it

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Exhibit A", result.Title);
    }

    // Test for returning exhibitions by id but designed to fail since it's not found
    [Fact]
    public async Task GetExhibitionByID_ReturnsNullIfNotFound()
    {
        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(false); // End the enumeration & async

        // Even though MoveNextAsync returns false, MongoDB driver might still access Current, so it must be set
        mockCursor.SetupGet(_ => _.Current).Returns(new List<Exhibition>());

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("99");

        // Assert
        Assert.Null(result);
    }

    // Test for inserting new exhibition into DB
    [Fact]
    public async Task InsertExhibitions_InsertsAndReturnsExhibition_WhenNotExists()
    {
        // Arrange
        var exhibitionToUpdate = new Exhibition
        {
            Id = "1",
            Title = "Exhibit A",
            StartDate = new DateTime(2024, 1, 1),
            EndDate = new DateTime(2024, 6, 1),
            Description = "Test A",
            Current = false
        };

        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Exhibition>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                exhibitionToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, exhibitionToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(exhibitionToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Exhibit A", result.Title);
    }

    // Test for inserting new exhibition into DB but it already exists
    [Fact]
    public async Task InsertExhibitions_ReturnsNull_WhenExhibitionAlreadyExists()
    {
        // Arrange
        var existingExhibition = new Exhibition
        {
            Id = "1",
            Title = "Exhibit A",
            StartDate = new DateTime(2024, 1, 1),
            EndDate = new DateTime(2024, 6, 1),
            Description = "Test A",
            Current = false
        };
        var exhibitionToUpdate = new Exhibition 
        {
            Id = "2",
            Title = "Exhibit B",
            StartDate = new DateTime(2024, 7, 1),
            EndDate = new DateTime(2024, 12, 1),
            Description = "Test B",
            Current = true
        };

        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Exhibition> { existingExhibition });
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(existingExhibition, false);

        // Assert
        Assert.Null(result); 
    }

    //Test to update exhibition that exists
    [Fact]
    public async void UpdateExhibitions_UpdatesAndReturnsExhibition()
    {
        // Arrange
        var exhibitionToUpdate = new Exhibition 
        {
            Id = "1",
            Title = "Exhibit A",
            StartDate = new DateTime(2024, 1, 1),
            EndDate = new DateTime(2024, 6, 1),
            Description = "Test A",
            Current = false
        };

        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Exhibition>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                exhibitionToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, exhibitionToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);

        // Act
        var result = await repo.UpdateAsync(exhibitionToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Exhibit A", result.Title);
    }

    // Updates exhibition but returns null since it doesn't exist
    [Fact]
    public async void UpdateExhibitions_ReturnsNull_OnException()
    {
        // Arrange
        var exhibition = new Exhibition
        {
            Id = "1",
            Title = "Exhibit A",
            StartDate = new DateTime(2024, 1, 1),
            EndDate = new DateTime(2024, 6, 1),
            Description = "Test A",
            Current = false
        };
        var exhibitionToUpdate = new Exhibition
        {
            Id = "2",
            Title = "Exhibit B",
            StartDate = new DateTime(2024, 7, 1),
            EndDate = new DateTime(2024, 12, 1),
            Description = "Test B",
            Current = true
        };

        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Exhibition> {exhibition});
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                exhibitionToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, exhibitionToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);

        // Act
        var result = await repo.UpdateAsync(exhibitionToUpdate, false);

        // Assert
        Assert.Null(result); 
    }

    // Test for deleting exhibition
    [Fact]
    public async Task DeleteExhibitions_DeletesExhibition()
    {
        // Arrange: Mock empty cursor for FindAsync (no exhibition found)
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Exhibition>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false);

        // Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Mock DeleteOneAsync to return a successful DeleteResult
        mockCollection.Setup(c => c.DeleteOneAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<DeleteResult>(r => r.IsAcknowledged == true && r.DeletedCount == 1));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);

        // Act
        await repo.DeleteAsync("1");

        // Assert: Verify DeleteOneAsync was called once with correct filter
        mockCollection.Verify(c => c.DeleteOneAsync(
            It.Is<FilterDefinition<Exhibition>>(f => true),  // you can refine this to match id "1"
            It.IsAny<CancellationToken>()), Times.Once);
    }

    // Test getting exhibitions by community
    [Fact]
    public async void GetExhibitionsByCommunity_ReturnsMatchingExhibitions()
    {
        // Arrange
        var exhibition = new Exhibition 
        {
            Id = "1",
            Title = "Exhibit A",
            StartDate = new DateTime(2024, 1, 1),
            EndDate = new DateTime(2024, 6, 1),
            Description = "Test A",
            Current = false
        };
        var exhibitionList = new List<Exhibition> { exhibition };

        // 1. Mock IAsyncCursor<Exhibition>
        var mockCursor = new Mock<IAsyncCursor<Exhibition>>();
        mockCursor.Setup(_ => _.Current).Returns(exhibitionList);  // Must return IEnumerable<Exhibition>
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<Exhibition>
        var mockCollection = new Mock<IMongoCollection<Exhibition>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Exhibition>>(),
                It.IsAny<FindOptions<Exhibition, Exhibition>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Exhibition>("exhibitions", null))
                    .Returns(mockCollection.Object);
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "exhibitions",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ExhibitionRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByCurrentAsync(false); 

        // Assert
        Assert.Single(result);
        Assert.Equal("Exhibit A", result[0].Title);
    }
}