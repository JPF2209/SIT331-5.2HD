using System.Threading.Tasks;
using art_api.Models;
using art_api.Persistence;

namespace art_api.Services
{
    public class ArtifactTypeDataAccess : IArtifactTypeDataAccess
    {
        private readonly IArtifactTypeRepository _artifactTypeRepository;

        public ArtifactTypeDataAccess(IArtifactTypeRepository artifactTypeRepository)
        {
            _artifactTypeRepository = artifactTypeRepository;
        }

        public Task<List<ArtifactType>> GetAllArtifactTypesAsync() // <-- Match the interface
        {
            return _artifactTypeRepository.GetAllAsync();
        }

        public Task<ArtifactType?> GetArtifactTypeByIdAsync(string id)
        {
            return _artifactTypeRepository.GetByIdAsync(id);
        }

        public async Task<ArtifactType?> InsertArtifactTypeAsync(ArtifactType artifactType)
        {
            //Checks if artifact type doesn't exist
            var existing = await _artifactTypeRepository.GetByTitleAsync(artifactType.Title);
            if (existing != null)
            {
                return null;
            }

            return await _artifactTypeRepository.InsertAsync(artifactType, true);
        }

        public async Task<ArtifactType?> UpdateArtifactTypeAsync(ArtifactType artifactType)
        {
            // Checks if artifact type exists
            var existing = await _artifactTypeRepository.GetByTitleAsync(artifactType.Title);
            if (existing == null)
            {
                return null;
            }
            return await _artifactTypeRepository.UpdateAsync(artifactType, true);
        }

        public async Task<bool> DeleteArtifactTypeAsync(string id)
        {
            return await _artifactTypeRepository.DeleteAsync(id);
        }
    }
}
