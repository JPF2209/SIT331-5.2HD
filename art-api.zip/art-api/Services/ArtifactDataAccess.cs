using System.Threading.Tasks;
using art_api.Models;
using art_api.Persistence;

namespace art_api.Services
{
    public class ArtifactDataAccess : IArtifactDataAccess
    {
        private readonly IArtifactRepository _artifactRepository;

        public ArtifactDataAccess(IArtifactRepository artifactRepository)
        {
            _artifactRepository = artifactRepository;
        }

        public Task<List<Artifact>> GetAllArtifactsAsync() // <-- Match the interface
        {
            return _artifactRepository.GetAllAsync();
        }

        public Task<Artifact?> GetArtifactByIdAsync(string id)
        {
            return _artifactRepository.GetByIdAsync(id);
        }

        public Task<List<Artifact>> GetFilteredArtifactsAsync(bool? framed, bool? @new, bool? staffPick)
        {
            return _artifactRepository.GetFilteredArtifactsAsync(framed, @new, staffPick);
        }

        public Task<List<Artifact>> GetArtifactsByTypeAsync(string typeTitle)
        {
            return _artifactRepository.GetArtifactsByTypeAsync(typeTitle);
        }

        public async Task<Artifact?> InsertArtifactAsync(Artifact artifact)
        {
            //Checks if artifact doesn't exist
            var existing = await _artifactRepository.GetByTitleAsync(artifact.Title);
            if (existing != null)
            {
                return null;
            }

            return await _artifactRepository.InsertAsync(artifact, true);
        }

        public async Task<Artifact?> UpdateArtifactAsync(Artifact artifact)
        {
            // Checks if artifact exists
            var existing = await _artifactRepository.GetByTitleAsync(artifact.Title);
            if (existing == null)
            {
                return null;
            }
            return await _artifactRepository.UpdateAsync(artifact, true);
        }

        public async Task<bool> DeleteArtifactAsync(string id)
        {
            return await _artifactRepository.DeleteAsync(id);
        }
    }
}
