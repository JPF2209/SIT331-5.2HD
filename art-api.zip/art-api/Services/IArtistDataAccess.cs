using System.Threading.Tasks;
using art_api.Models;

namespace art_api.Services
{
    public interface IArtistDataAccess
    {
        Task<List<Artist>> GetAllArtistsAsync(); 
        Task<Artist?> GetArtistByIdAsync(string id);
        Task<List<Artist>> GetArtistByCommunityAsync(string community);
        Task<Artist?> InsertArtistAsync(Artist artist);
        Task<Artist?> UpdateArtistAsync(Artist artist);
        Task<bool> DeleteArtistAsync(string id); 
    }
}
