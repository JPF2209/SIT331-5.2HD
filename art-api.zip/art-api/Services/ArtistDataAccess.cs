using System.Threading.Tasks;
using art_api.Models;
using art_api.Persistence;

namespace art_api.Services
{
    public class ArtistDataAccess : IArtistDataAccess
    {
        private readonly IArtistRepository _artistRepository;

        public ArtistDataAccess(IArtistRepository artistRepository)
        {
            _artistRepository = artistRepository;
        }

        public Task<List<Artist>> GetAllArtistsAsync() // <-- Match the interface
        {
            return _artistRepository.GetAllAsync();
        }

        public Task<Artist?> GetArtistByIdAsync(string id)
        {
            return _artistRepository.GetByIdAsync(id);
        }

        public Task<List<Artist>> GetArtistByCommunityAsync(string community)
        {
            return _artistRepository.GetByCommunityAsync(community);
        }

        public async Task<Artist?> InsertArtistAsync(Artist artist)
        {
            //Checks if artist doesn't exist
            var existing = await _artistRepository.GetByNameAsync(artist.Name);
            if (existing != null)
            {
                return null;
            }

            return await _artistRepository.InsertAsync(artist, true);
        }

        public async Task<Artist?> UpdateArtistAsync(Artist artist)
        {
            // Checks if artist exists
            var existing = await _artistRepository.GetByNameAsync(artist.Name);
            if (existing == null)
            {
                return null;
            }
            return await _artistRepository.UpdateAsync(artist, true);
        }

        public async Task<bool> DeleteArtistAsync(string id)
        {
            return await _artistRepository.DeleteAsync(id);
        }
    }
}
