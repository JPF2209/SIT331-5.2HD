using System.Threading.Tasks;
using art_api.Models;

namespace art_api.Services
{
    public interface IArtifactTypeDataAccess
    {
        Task<List<ArtifactType>> GetAllArtifactTypesAsync(); 
        Task<ArtifactType?> GetArtifactTypeByIdAsync(string id);
        Task<ArtifactType?> InsertArtifactTypeAsync(ArtifactType artifactType);
        Task<ArtifactType?> UpdateArtifactTypeAsync(ArtifactType artifactType);
        Task<bool> DeleteArtifactTypeAsync(string id); 
    }
}
