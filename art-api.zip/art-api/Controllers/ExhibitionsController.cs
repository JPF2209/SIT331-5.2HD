using Microsoft.AspNetCore.Mvc;
using art_api.Services;
using art_api.Models;

namespace art_api.Controllers;

[ApiController]
[Route("api/exhibition")]
public class ExhibitionsController : ControllerBase
{
    private readonly IExhibitionDataAccess _exhibitionsRepo;
    
    public ExhibitionsController(IExhibitionDataAccess exhibitionsRepo)
    {
        _exhibitionsRepo = exhibitionsRepo;
    }

    // Controller for getting all exhibitions
    [HttpGet("")]
    public async Task<ActionResult<IEnumerable<Exhibition>>> GetAll()
    {
        var exhibitions = await _exhibitionsRepo.GetAllExhibitionsAsync();
        return Ok(exhibitions);
    }

    // Controller for getting exhibitions by id
    [HttpGet("{id}", Name = "GetExhibition")]
    public async Task<ActionResult<Exhibition>> GetById(string id)
    {
        var exhibition = await _exhibitionsRepo.GetExhibitionByIdAsync(id);
        
        // If it's null, it's not found
        if (exhibition == null)
            return NotFound();

        return Ok(exhibition);
    }

    // Controller for getting exhibitions by current
    [HttpGet("by-current")]
    public async Task<ActionResult<Exhibition>> GetexhibitionsByCurrent(bool current)
    {
        var exhibition = await _exhibitionsRepo.GetExhibitionByCurrentAsync(current); 
        
        // If exhibition doesn't exist, return null
        if (exhibition == null)
            return NotFound();
        return Ok(exhibition);
    }

    // Controller for inserting exhibitions    
    [HttpPost]
    public async Task<IActionResult> AddExhibition([FromBody] Exhibition newExhibition)
    {
        // If new exhibition is null it's a bad request
        if (newExhibition == null)
        {
            return BadRequest("Exhibition is null.");
        }

        var exhibition = await _exhibitionsRepo.InsertExhibitionAsync(newExhibition);
        
        // If the inserted value is null, a check was made and the exhibition already exists
        if (exhibition == null)
        {
            return Conflict("Exhibition already exists.");
        }

        return CreatedAtRoute("GetExhibition", new { id = exhibition.Id }, exhibition);
    }

    // Controller for updating exhibitions
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateExhibition(string id, [FromBody] Exhibition updatedExhibition)
    {
        // If updated exhibition id doesn't match what in the body or if the body is null
        if (id != updatedExhibition.Id)
            return BadRequest();

        var result = await _exhibitionsRepo.UpdateExhibitionAsync(updatedExhibition);

        // If exhibition it's searching for doesn't exist or if there's a duplicate title for the exhibition
        if (result == null)
            return NotFound();

        return Ok(result);
    }

    // Controller for deleting exhibitions
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteExhibition(string id)
    {
        var deleted = await _exhibitionsRepo.DeleteExhibitionAsync(id);
        
        // If not a success (bool), the id didn't exist
        if (!deleted)
            return NotFound();

        return NoContent(); 
    }
}
