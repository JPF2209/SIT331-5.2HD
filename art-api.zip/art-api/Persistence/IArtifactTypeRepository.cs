using art_api.Models;

namespace art_api.Persistence
{
    public interface IArtifactTypeRepository
    {
        Task<ArtifactType?> GetByTitleAsync(string Title);
        Task<ArtifactType> InsertAsync(ArtifactType artifactType, bool isChecked);
        Task<List<ArtifactType>> GetAllAsync();    
        Task<ArtifactType?> GetByIdAsync(string id);    
        Task<ArtifactType?> UpdateAsync(ArtifactType artifactType, bool isChecked);
        Task<bool> DeleteAsync(string id);
    }
}