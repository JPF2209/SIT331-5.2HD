using art_api.Models;

namespace art_api.Persistence
{
    public interface IArtistRepository
    {
        Task<Artist?> GetByNameAsync(string name);
        Task<Artist> InsertAsync(Artist artist, bool isChecked);
        Task<List<Artist>> GetAllAsync();    
        Task<Artist?> GetByIdAsync(string id);  
        Task<List<Artist>> GetByCommunityAsync(string id);  
        Task<Artist?> UpdateAsync(Artist artist, bool isChecked);
        Task<bool> DeleteAsync(string id);
    }
}