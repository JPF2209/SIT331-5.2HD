using art_api.Models;

namespace art_api.Persistence
{
    public interface IExhibitionRepository
    {
        Task<Exhibition?> GetByTitleAsync(string title);
        Task<Exhibition> InsertAsync(Exhibition exhibition, bool isChecked);
        Task<List<Exhibition>> GetAllAsync();    
        Task<Exhibition?> GetByIdAsync(string id);  
        Task<List<Exhibition>> GetByCurrentAsync(bool current);  
        Task<Exhibition?> UpdateAsync(Exhibition exhibition, bool isChecked);
        Task<bool> DeleteAsync(string id);
    }
}