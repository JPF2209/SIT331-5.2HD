using art_api.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using art_api.Settings;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;
namespace art_api.Persistence
{
    public class ArtifactTypeRepository : IArtifactTypeRepository
    {
        private readonly IMongoCollection<ArtifactType> _collection;

        public ArtifactTypeRepository(IOptions<MongoDbSettings> settings, IMongoClient client)
        {
            var db = client.GetDatabase(settings.Value.DatabaseName); // e.g., "Mongo"
            _collection = db.GetCollection<ArtifactType>("artifacttypes");
        }

        public async Task<ArtifactType?> GetByTitleAsync(string Title)
        {
            return await _collection.Find(a => a.Title == Title).FirstOrDefaultAsync();
        }

        public async Task<ArtifactType> InsertAsync(ArtifactType artifactType, bool isChecked)
        {
            // For Xunit test, check if not in DB
            if (isChecked == false)
            {
                var filter = Builders<ArtifactType>.Filter.Eq(a => a.Title, artifactType.Title);
                var existing = await _collection.Find(filter).FirstOrDefaultAsync();

                if (existing != null)
                    return null;
            }
            await _collection.InsertOneAsync(artifactType);
            return artifactType;
        }

        public async Task<List<ArtifactType>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task<ArtifactType?> GetByIdAsync(string id)
        {
            return await _collection.Find(a => a.Id == id).FirstOrDefaultAsync();
        }

        public async Task<ArtifactType> UpdateAsync(ArtifactType artifactType, bool isChecked)
        {
            // For Xunit test, check if in DB
            if (isChecked == false)
            {
                var existingArtifactType = await _collection.Find(a => a.Title == artifactType.Title).FirstOrDefaultAsync();

                if (existingArtifactType != null)
                {
                    return null;
                }
            }
            var filter = Builders<ArtifactType>.Filter.Eq(a => a.Id, artifactType.Id);
            var result = await _collection.ReplaceOneAsync(filter, artifactType);

            // If it updated, return exhibition
            if (result.IsAcknowledged && result.ModifiedCount > 0)
                return artifactType;

            return null; // Update failed
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var result = await _collection.DeleteOneAsync(a => a.Id == id);
            return result.DeletedCount > 0;
        }
    }
}