using art_api.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using art_api.Settings;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;
namespace art_api.Persistence
{
    public class ArtistRepository : IArtistRepository
    {
        private readonly IMongoCollection<Artist> _collection;

        public ArtistRepository(IOptions<MongoDbSettings> settings, IMongoClient client)
        {
            var db = client.GetDatabase(settings.Value.DatabaseName); // e.g., "Mongo"
            _collection = db.GetCollection<Artist>("artists");
        }

        public async Task<Artist?> GetByNameAsync(string name)
        {
            return await _collection.Find(a => a.Name == name).FirstOrDefaultAsync();
        }

        public async Task<Artist> InsertAsync(Artist artist, bool isChecked)
        {
            // For Xunit test, check if not in DB
            if (isChecked == false)
            {
                var filter = Builders<Artist>.Filter.Eq(a => a.Name, artist.Name);
                var existing = await _collection.Find(filter).FirstOrDefaultAsync();

                if (existing != null)
                    return null;
            }
            await _collection.InsertOneAsync(artist);
            return artist;
        }

        public async Task<List<Artist>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task<Artist?> GetByIdAsync(string id)
        {
            return await _collection.Find(a => a.Id == id).FirstOrDefaultAsync();
        }

        public async Task<List<Artist>> GetByCommunityAsync(string community)
        {
            return await _collection.Find(a => a.Community == community).ToListAsync();
        }

        public async Task<Artist> UpdateAsync(Artist artist, bool isChecked)
        {
            // For Xunit test, check if in DB
            if (isChecked == false)
            {
                var existingArtist = await _collection.Find(a => a.Name == artist.Name).FirstOrDefaultAsync();

                if (existingArtist != null)
                {
                    return null;
                }
            }
            var filter = Builders<Artist>.Filter.Eq(a => a.Id, artist.Id);
            var result = await _collection.ReplaceOneAsync(filter, artist);

            // If it updated, return exhibition
            if (result.IsAcknowledged && result.ModifiedCount > 0)
                return artist;

            return null; // Update failed
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var result = await _collection.DeleteOneAsync(a => a.Id == id);
            return result.DeletedCount > 0;
        }
    }
}